# ═══════════════════════════════════════════════════════════
# main.py — API Garra Gestão v6 — UNIFICADO
# FastAPI + asyncpg + Neon PostgreSQL
# Módulos: Checklist + Jardinagem
# ═══════════════════════════════════════════════════════════

from fastapi import FastAPI, HTTPException, Depends, Header, Request, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional, List
import asyncpg, bcrypt, os, json, time, secrets, smtplib, uuid, io, calendar
from dotenv import load_dotenv
load_dotenv()
import psycopg2, psycopg2.extras
import jwt as pyjwt
import requests as req_lib
from datetime import datetime, timedelta, date
from collections import defaultdict
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from PIL import Image

app = FastAPI(title="Garra Gestão API", version="6.0.0")  # main em admin/api/main.py

# ══════════════════════════════════════════════════════════════
# CORE — Refatoração Fase 1 (03/07/2026)
# Config, banco, auth, storage, helpers, models e permissões vivem
# em admin/api/core/. As rotas permanecem TODAS neste arquivo até a
# Fase 2 (routers). Golden test: auditoria_rotas.py (150 rotas).
# ══════════════════════════════════════════════════════════════
from core.config import (
    DATABASE_URL, FRONTEND_URL,
    SUPABASE_URL, SUPABASE_SERVICE_KEY, BUCKET_ATUAL,
    MAIL_HOST, MAIL_PORT, MAIL_USERNAME, MAIL_PASSWORD, MAIL_CC, MAIL_DESTINO,
    JWT_SECRET, JWT_EXPIRY_HOURS, DEBUG_KEY, _debug_autorizado,
)
from core.db import get_db, get_jard_db, jard_query, jard_query_id
from core.storage import (
    storage_upload, storage_url, storage_delete, _URL_SUPABASE_EXPIRY,
    _checklist_extrair_fotos_para_storage, _checklist_assinar_fotos_para_leitura,
)
from core.auth import (
    check_rate_limit, _login_attempts,
    gerar_token_jard, verificar_token_jard, exigir_acesso_jardinagem,
    verificar_token, verificar_admin, verificar_gestor, validar_senha,
)
from core.helpers import comprimir_imagem, next_code, semanas_do_mes, enviar_email_smtp
from core.models import (
    LoginRequest, UsuarioCreate, UsuarioEdit, SenhaChange,
    SenhaResetRequest, SenhaResetConfirm, EnvioCreate, FrotaItem,
    ChecklistModeloCreate, LogMotoristaCreate, LogVeiculoCreate, LogRegistroCreate,
)
from core.permissions import (
    MODULOS_DISPONIVEIS, PERFIL_MODULOS_PADRAO, PERFIL_LABEL_SEED,
    PERFIS_TABLE_SQL, perfil_modulos_padrao,
)

# ── CORS ──────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://garra-checklist-app.onrender.com",
        "https://garra-sistemas.onrender.com",
        "https://garra-jardinagem-app.onrender.com",  # Static Site PWA mobile
        "http://localhost:8000",   # Dev local
        "http://127.0.0.1:8000",  # Dev local alternativo
        "http://localhost:3000",
        "http://127.0.0.1:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["Content-Type","Authorization"],
)

# ── SECURITY HEADERS ──────────────────────────────────────────
@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"]  = "nosniff"
    response.headers["X-Frame-Options"]         = "SAMEORIGIN"
    response.headers["X-XSS-Protection"]        = "1; mode=block"
    response.headers["Referrer-Policy"]         = "strict-origin-when-cross-origin"
    return response

# ══════════════════════════════════════════════════════════════
# BANCO — DOIS MODOS
# asyncpg (async) → checklist
# psycopg2 (sync) → jardinagem (mantém compatibilidade)
# ══════════════════════════════════════════════════════════════

# ── STARTUP ───────────────────────────────────────────────────
@app.on_event("startup")
async def startup():
    """
    Startup resiliente: tenta conectar e rodar migrations, mas NUNCA derruba
    o app se o banco estiver dormindo/acordando ou com cota excedida.
    As migrations rodam na primeira conexão bem-sucedida; se falharem aqui,
    o app sobe mesmo assim (as tabelas já existem em produção) e o banco é
    acessado sob demanda nas rotas.
    """
    import asyncio
    conn = None
    # Tenta conectar com retry curto — banco pode estar "acordando"
    for tentativa in range(1, 4):
        try:
            conn = await asyncio.wait_for(asyncpg.connect(DATABASE_URL), timeout=10)
            break
        except Exception as e:
            print(f"[Startup] tentativa {tentativa}/3 de conexão falhou: {type(e).__name__}: {e}")
            if tentativa < 3:
                await asyncio.sleep(2 * tentativa)

    if conn is None:
        # Banco indisponível (dormindo, cota, rede). App sobe assim mesmo.
        # As rotas que precisam do banco vão tentar conectar sob demanda.
        print("[Startup] ⚠️ Banco indisponível no boot — app subindo sem migrations. "
              "Serão aplicadas na próxima vez que o banco responder.")
        return

    try:
        await conn.execute("SET search_path TO public, checklist, jardinagem")
        print("Garra Gestao - banco conectado")
        print("JARD_DIR:", JARD_DIR)
        print("TEMPLATES exists:", os.path.exists(TEMPLATES_DIR))
        print("STATIC exists:", os.path.exists(STATIC_DIR))

        # Migration: adicionar coluna medicao em operacional.tipos_servico
        try:
            await conn.execute("""
                ALTER TABLE operacional.tipos_servico
                ADD COLUMN IF NOT EXISTS medicao TEXT DEFAULT 'horimetro'
            """)
            await conn.execute("""
                ALTER TABLE operacional.tipos_servico
                ADD COLUMN IF NOT EXISTS ativo BOOLEAN DEFAULT TRUE
            """)
            # Migration: adicionar qtd_metros em partes_diarias
            await conn.execute("""
                ALTER TABLE operacional.partes_diarias
                ADD COLUMN IF NOT EXISTS qtd_metros NUMERIC(10,2)
            """)
            # Migration: coluna de diárias cobradas (ajuste pela Luana)
            await conn.execute("""
                ALTER TABLE operacional.partes_diarias
                ADD COLUMN IF NOT EXISTS quantidade_diarias_cobradas NUMERIC(8,1)
            """)
            # Migration: coluna fornecedor (terceiro/diarista/frete)
            await conn.execute("""
                ALTER TABLE operacional.partes_diarias
                ADD COLUMN IF NOT EXISTS fornecedor TEXT
            """)
            # Migration: flag de dia corrido (sem desconto de almoço)
            await conn.execute("""
                ALTER TABLE operacional.partes_diarias
                ADD COLUMN IF NOT EXISTS sem_almoco BOOLEAN DEFAULT false
            """)
            # Migration: nome do equipamento de terceiro (quando vínculo=terceiro)
            await conn.execute("""
                ALTER TABLE operacional.partes_diarias
                ADD COLUMN IF NOT EXISTS equipamento_terceiro TEXT
            """)
            # Migration: criar tabela regimes_cobranca
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS operacional.regimes_cobranca (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    nome TEXT NOT NULL UNIQUE,
                    descricao TEXT,
                    ativo BOOLEAN DEFAULT TRUE,
                    criado_em TIMESTAMP DEFAULT NOW()
                )
            """)
            # Inserir regimes padrão se tabela vazia
            await conn.execute("""
                INSERT INTO operacional.regimes_cobranca (nome, descricao)
                VALUES ('hora', 'Cobrança por hora trabalhada'),
                       ('diaria', 'Cobrança por diária'),
                       ('empreito', 'Valor fechado por empreita'),
                       ('metro', 'Cobrança por metro executado')
                ON CONFLICT (nome) DO NOTHING
            """)
            # Migration: log de ajuste de pontos
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS public.log_ajuste_pontos (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    usuario_login TEXT NOT NULL,
                    usuario_nome TEXT,
                    pts_antes INTEGER,
                    ajuste INTEGER NOT NULL,
                    pts_depois INTEGER,
                    motivo TEXT NOT NULL,
                    ajustado_por TEXT,
                    criado_em TIMESTAMP DEFAULT NOW()
                )
            """)
            # Migration: clientes_garra — garantir colunas de cadastro
            await conn.execute("""
                ALTER TABLE public.clientes_garra
                ADD COLUMN IF NOT EXISTS cnpj_cpf TEXT,
                ADD COLUMN IF NOT EXISTS telefone TEXT,
                ADD COLUMN IF NOT EXISTS email TEXT,
                ADD COLUMN IF NOT EXISTS endereco TEXT,
                ADD COLUMN IF NOT EXISTS cidade TEXT,
                ADD COLUMN IF NOT EXISTS uf TEXT,
                ADD COLUMN IF NOT EXISTS contato TEXT,
                ADD COLUMN IF NOT EXISTS observacao TEXT,
                ADD COLUMN IF NOT EXISTS ativo BOOLEAN DEFAULT TRUE,
                ADD COLUMN IF NOT EXISTS criado_em TIMESTAMP DEFAULT NOW()
            """)
            # Migration: equipamentos — garantir colunas para CRUD
            await conn.execute("""
                ALTER TABLE operacional.equipamentos
                ADD COLUMN IF NOT EXISTS marca TEXT,
                ADD COLUMN IF NOT EXISTS modelo TEXT,
                ADD COLUMN IF NOT EXISTS ano INTEGER,
                ADD COLUMN IF NOT EXISTS placa TEXT,
                ADD COLUMN IF NOT EXISTS operador_responsavel_id UUID REFERENCES public.usuarios_garra(id),
                ADD COLUMN IF NOT EXISTS ativo BOOLEAN DEFAULT TRUE,
                ADD COLUMN IF NOT EXISTS criado_em TIMESTAMP DEFAULT NOW()
            """)
            print("[Migration] colunas medicao/ativo/qtd_metros/clientes/equipamentos OK")
        except Exception as me:
            print(f"[Migration] aviso (não-fatal): {me}")
    except Exception as e:
        print("Erro no startup (não-fatal):", e)
    finally:
        try:
            await conn.close()
        except Exception:
            pass

# ── STATIC FILES — JARDINAGEM ─────────────────────────────────
# checklist/api/main.py → checklist/ → raiz → jardinagem/
# Em Render, o working directory é a raiz do repo
import sys
current_file = os.path.abspath(__file__)
possible_paths = [
    os.path.join(os.path.dirname(current_file), "..", "..", "jardinagem"),  # Local dev
    "/app/jardinagem",  # Render default
    os.path.join(os.getcwd(), "jardinagem"),  # Render com working dir = raiz
]

JARD_DIR = None
for path in possible_paths:
    if os.path.exists(os.path.join(path, "templates")):
        JARD_DIR = os.path.abspath(path)
        break

if not JARD_DIR:
    JARD_DIR = os.path.abspath(possible_paths[0])  # Fallback

STATIC_DIR    = os.path.join(JARD_DIR, "static")
TEMPLATES_DIR = os.path.join(JARD_DIR, "templates")

print(f"JARD_DIR: {JARD_DIR}")
print(f"TEMPLATES_DIR: {TEMPLATES_DIR} (exists: {os.path.exists(TEMPLATES_DIR)})")
print(f"STATIC_DIR: {STATIC_DIR} (exists: {os.path.exists(STATIC_DIR)})")

if os.path.exists(STATIC_DIR):
    app.mount("/jardinagem/static", StaticFiles(directory=STATIC_DIR), name="jard_static")

# Ícones da jardinagem — o pwa-app.html referencia ./icons/ (= /jardinagem/icons/),
# mas os arquivos vivem em jardinagem/static/icons/. Sem este mount: 404 no ícone
# do PWA, favicons e logo do header.
JARD_ICONS_DIR = os.path.join(STATIC_DIR, "icons")
if os.path.exists(JARD_ICONS_DIR):
    app.mount("/jardinagem/icons", StaticFiles(directory=JARD_ICONS_DIR), name="jard_icons")

# Ícones globais — servidos como /static/icons/ para todos os módulos
ICONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "operacional", "checklist", "icons")
if os.path.exists(ICONS_DIR):
    app.mount("/static/icons", StaticFiles(directory=ICONS_DIR), name="static_icons")
    print(f"ICONS_DIR: {ICONS_DIR} (exists: True)")

# Operacional static files (idb.js, sw.js, offline-ui.js, etc)
OPERACIONAL_STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "operacional", "static")
if os.path.exists(OPERACIONAL_STATIC_DIR):
    # Rota dedicada para sw.js com header Service-Worker-Allowed: /
    # Permite o SW ter scope na raiz do site mesmo sendo servido de subpasta
    @app.get("/operacional/static/sw.js")
    async def serve_sw_js():
        return FileResponse(
            os.path.join(OPERACIONAL_STATIC_DIR, "sw.js"),
            media_type="application/javascript",
            headers={"Service-Worker-Allowed": "/"}
        )
    app.mount("/operacional/static", StaticFiles(directory=OPERACIONAL_STATIC_DIR), name="operacional_static")
    print(f"OPERACIONAL_STATIC_DIR: {OPERACIONAL_STATIC_DIR} (exists: True)")

# Assets do checklist (css, js)
CHECKLIST_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "operacional", "checklist")
if os.path.exists(CHECKLIST_DIR):
    app.mount("/checklist/css",      StaticFiles(directory=os.path.join(CHECKLIST_DIR, "css")), name="checklist_css")
    app.mount("/checklist/js",       StaticFiles(directory=os.path.join(CHECKLIST_DIR, "js")),  name="checklist_js")
    app.mount("/checklist/icons",    StaticFiles(directory=os.path.join(CHECKLIST_DIR, "icons")), name="checklist_icons_sub")
    # Caminhos relativos do checklist quando carregado no iframe
    if os.path.exists(os.path.join(CHECKLIST_DIR, "css")):
        app.mount("/css", StaticFiles(directory=os.path.join(CHECKLIST_DIR, "css")), name="checklist_css_rel")
    if os.path.exists(os.path.join(CHECKLIST_DIR, "js")):
        app.mount("/js",  StaticFiles(directory=os.path.join(CHECKLIST_DIR, "js")),  name="checklist_js_rel")
    if os.path.exists(os.path.join(CHECKLIST_DIR, "icons")):
        app.mount("/icons", StaticFiles(directory=os.path.join(CHECKLIST_DIR, "icons")), name="checklist_icons_rel")



@app.post("/auth/login")
async def login(req: LoginRequest, request: Request, db=Depends(get_db)):
    check_rate_limit(request.client.host)
    user = await db.fetchrow(
        "SELECT * FROM public.usuarios_garra WHERE (login=$1 OR email=$1) AND ativo=TRUE",
        req.login
    )
    if not user or not bcrypt.checkpw(req.senha.encode(), user["senha_hash"].encode()):
        raise HTTPException(status_code=401, detail="Usuário ou senha incorretos")
    token = pyjwt.encode({
        "sub":              user["login"],
        "login":            user["login"],
        "nome":             user["nome"],
        "perfil":           user["perfil"],
        "perfil_checklist": user["perfil_checklist"],
        "exp":              datetime.utcnow() + timedelta(hours=JWT_EXPIRY_HOURS)
    }, JWT_SECRET, algorithm="HS256")
    
    # Determinar redirect_url baseado no perfil
    redirects = {
        "admin": "/admin",
        "gestor": "/admin",
        "luana": "/admin",
        "campo": "/mobile",
        "operador": "/mobile",
        "motorista": "/mobile",
        "bruna": "/mobile"
    }
    redirect_url = redirects.get(user["perfil"], "/admin")
    
    # Carregar permissões efetivas (DB + padrão do perfil)
    try:
        rows_perm = await db.fetch(
            "SELECT modulo, permitido FROM public.permissoes_colaborador WHERE usuario_id=$1",
            user["id"]
        )
        perms = {r["modulo"]: r["permitido"] for r in (rows_perm or [])}
        padrao = perfil_modulos_padrao(user["perfil"])
        for m in MODULOS_DISPONIVEIS:
            if m["id"] not in perms:
                perms[m["id"]] = m["id"] in padrao
    except Exception:
        perms = {}
    
    return {
        "token": token,
        "id": str(user["id"]),
        "login": user["login"], "nome": user["nome"],
        "perfil": user["perfil"], "perfil_checklist": user["perfil_checklist"],
        "role": user["perfil_checklist"] or user["perfil"],
        "redirect_url": redirect_url,
        "permsDB": perms,
        "pts": user["pts"] or 0, "total_envios": user["total_envios"] or 0,
        "email": user["email"] or "",
    }

@app.post("/auth/solicitar-reset")
async def solicitar_reset(req: SenhaResetRequest, db=Depends(get_db)):
    user = await db.fetchrow(
        "SELECT id, nome, email FROM public.usuarios_garra WHERE login=$1 AND ativo=TRUE", req.login
    )
    if not user or not user["email"]:
        return {"ok": True, "msg": "Se o usuário existir, um email será enviado."}
    token = secrets.token_urlsafe(32)
    await db.execute(
        "INSERT INTO public.senha_reset_tokens (usuario_id, token) VALUES ($1,$2)",
        user["id"], token
    )
    link = f"{FRONTEND_URL}/reset-senha.html?token={token}"
    corpo = f"""<div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;">
      <div style="background:#1A2A5E;padding:20px;border-bottom:3px solid #E8820C;">
        <h2 style="color:#fff;margin:0;">Garra Terraplenagem</h2></div>
      <div style="padding:24px;background:#F0F4FF;">
        <p>Olá, <strong>{user['nome']}</strong>!</p>
        <p>Recebemos uma solicitação para redefinir sua senha.</p>
        <p style="margin:24px 0;">
          <a href="{link}" style="background:#1A2A5E;color:#fff;padding:12px 24px;
             border-radius:8px;text-decoration:none;font-weight:bold;">Redefinir minha senha</a></p>
        <p style="color:#64748B;font-size:12px;">Este link expira em 1 hora.</p>
      </div></div>"""
    try:
        enviar_email_smtp(user["email"], "Redefinição de senha — Garra Gestão", corpo)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Erro ao enviar email.")
    return {"ok": True, "msg": "Email enviado com sucesso."}

@app.post("/auth/confirmar-reset")
async def confirmar_reset(req: SenhaResetConfirm, db=Depends(get_db)):
    erro = validar_senha(req.senha_nova)
    if erro: raise HTTPException(status_code=400, detail=erro)
    token_row = await db.fetchrow(
        """SELECT t.*, u.id as uid FROM public.senha_reset_tokens t
           JOIN public.usuarios_garra u ON u.id=t.usuario_id
           WHERE t.token=$1 AND t.usado=FALSE AND t.expira_em > NOW()""", req.token
    )
    if not token_row: raise HTTPException(status_code=400, detail="Token inválido ou expirado.")
    novo_hash = bcrypt.hashpw(req.senha_nova.encode(), bcrypt.gensalt(12)).decode()
    await db.execute(
        "UPDATE public.usuarios_garra SET senha_hash=$1, atualizado_em=NOW() WHERE id=$2",
        novo_hash, token_row["uid"]
    )
    await db.execute("UPDATE public.senha_reset_tokens SET usado=TRUE WHERE token=$1", req.token)
    return {"ok": True, "msg": "Senha redefinida com sucesso."}

@app.post("/auth/renovar")
async def renovar_token(payload=Depends(verificar_token)):
    """Token válido → gera novo com validade renovada. Chamado silenciosamente ao abrir o app."""
    novo_token = pyjwt.encode({
        "sub":              payload["sub"],
        "login":            payload.get("login") or payload.get("sub", ""),
        "nome":             payload.get("nome", ""),
        "perfil":           payload.get("perfil", ""),
        "perfil_checklist": payload.get("perfil_checklist", ""),
        "exp":              datetime.utcnow() + timedelta(hours=JWT_EXPIRY_HOURS)
    }, JWT_SECRET, algorithm="HS256")

    login = payload.get("login") or payload.get("sub", "")
    user = jard_query(
        "SELECT id, perfil, pts, total_envios FROM public.usuarios_garra WHERE (login=%s OR email=%s) AND ativo=true",
        (login, login), fetch="one"
    )

    # Carregar permissões efetivas (DB + padrão do perfil) — mesma lógica do /auth/login
    perms = {}
    if user:
        try:
            perfil = user.get("perfil") or payload.get("perfil", "")
            rows_perm = jard_query(
                "SELECT modulo, permitido FROM public.permissoes_colaborador WHERE usuario_id=%s",
                (str(user["id"]),), fetch="all"
            )
            perms = {r["modulo"]: r["permitido"] for r in (rows_perm or [])}
            padrao = perfil_modulos_padrao(perfil)
            for m in MODULOS_DISPONIVEIS:
                if m["id"] not in perms:
                    perms[m["id"]] = m["id"] in padrao
        except Exception:
            perms = {}

    return {
        "token": novo_token,
        "id": str(user["id"]) if user else None,
        "login": login,
        "nome": payload.get("nome", ""),
        "perfil": payload.get("perfil", ""),
        "perfil_checklist": payload.get("perfil_checklist", ""),
        "pts": (user["pts"] if user else 0) or 0,
        "total_envios": (user["total_envios"] if user else 0) or 0,
        "permsDB": perms,
    }

@app.post("/auth/alterar-senha")
async def alterar_senha(req: SenhaChange, db=Depends(get_db), _auth=Depends(verificar_token)):
    # Login vem do token do usuário logado (não query param) — mais seguro
    login = _auth.get("sub") or _auth.get("login")
    if not login:
        raise HTTPException(status_code=401, detail="Token inválido")
    erro = validar_senha(req.senha_nova)
    if erro: raise HTTPException(status_code=400, detail=erro)
    user = await db.fetchrow("SELECT * FROM public.usuarios_garra WHERE login=$1", login)
    if not user: raise HTTPException(status_code=404, detail="Usuário não encontrado")
    if not bcrypt.checkpw(req.senha_atual.encode(), user["senha_hash"].encode()):
        raise HTTPException(status_code=401, detail="Senha atual incorreta")
    novo_hash = bcrypt.hashpw(req.senha_nova.encode(), bcrypt.gensalt(12)).decode()
    await db.execute(
        "UPDATE public.usuarios_garra SET senha_hash=$1, atualizado_em=NOW() WHERE login=$2",
        novo_hash, login
    )
    return {"ok": True}

@app.get("/usuarios")
async def listar_usuarios(db=Depends(get_db), _auth=Depends(verificar_token)):
    rows = await db.fetch(
        "SELECT id,login,nome,email,perfil,perfil_checklist,pts,total_envios,ativo,criado_em FROM public.usuarios_garra ORDER BY nome"
    )
    return [dict(r) for r in rows]

@app.post("/usuarios")
async def criar_usuario(u: UsuarioCreate, db=Depends(get_db), _auth=Depends(verificar_admin)):
    erro = validar_senha(u.senha)
    if erro: raise HTTPException(status_code=400, detail=erro)
    existe = await db.fetchval(
        "SELECT id FROM public.usuarios_garra WHERE login=$1 OR email=$2", u.login, u.email
    )
    if existe: raise HTTPException(status_code=409, detail="Login ou email já cadastrado.")
    hash_senha = bcrypt.hashpw(u.senha.encode(), bcrypt.gensalt(12)).decode()
    await db.execute(
        "INSERT INTO public.usuarios_garra (login,nome,email,senha_hash,perfil,perfil_checklist) VALUES ($1,$2,$3,$4,$5,$6)",
        u.login, u.nome, u.email, hash_senha, u.perfil, u.perfil_checklist
    )
    return {"ok": True}

@app.post("/usuarios/{login}/editar")
async def editar_usuario(login: str, dados: UsuarioEdit, db=Depends(get_db), _auth=Depends(verificar_admin)):
    d = dados.dict(exclude_none=True)
    # Senha é tratada à parte: NUNCA vai direto pro SET (a coluna é senha_hash
    # e o valor precisa de bcrypt). Antes deste fix, o campo era descartado
    # silenciosamente pelo Pydantic — a troca de senha pelo Admin não funcionava.
    senha = d.pop("senha", None)
    sets, params = [], []
    for campo, valor in d.items():
        params.append(valor); sets.append(f"{campo}=${len(params)}")
    if senha:
        erro = validar_senha(senha)
        if erro: raise HTTPException(status_code=400, detail=erro)
        novo_hash = bcrypt.hashpw(senha.encode(), bcrypt.gensalt(12)).decode()
        params.append(novo_hash); sets.append(f"senha_hash=${len(params)}")
    if not sets: return {"ok": True}
    params.append(login)
    await db.execute(
        f"UPDATE public.usuarios_garra SET {','.join(sets)},atualizado_em=NOW() WHERE login=${len(params)}", *params
    )
    return {"ok": True}

@app.delete("/usuarios/{login}")
async def remover_usuario(login: str, db=Depends(get_db), _auth=Depends(verificar_admin)):
    await db.execute("UPDATE public.usuarios_garra SET ativo=FALSE WHERE login=$1", login)
    return {"ok": True}

@app.patch("/usuarios/{login}/pts")
async def atualizar_pts(login: str, pts: int, db=Depends(get_db), _auth=Depends(verificar_token)):
    await db.execute(
        "UPDATE public.usuarios_garra SET pts=$1, atualizado_em=NOW() WHERE login=$2", pts, login
    )
    return {"ok": True}


@app.post("/usuarios/{login}/ajustar-pts")
async def ajustar_pts(login: str, request: Request, db=Depends(get_db), _auth=Depends(verificar_gestor)):
    """Ajusta pontos (subtrair ou adicionar) com motivo registrado."""
    body = await request.json()
    ajuste = int(body.get("ajuste", 0))
    motivo = (body.get("motivo") or "").strip()
    if ajuste == 0:
        raise HTTPException(status_code=400, detail="Ajuste não pode ser zero")
    if not motivo:
        raise HTTPException(status_code=400, detail="Motivo é obrigatório")

    # Buscar usuário
    user = await db.fetchrow(
        "SELECT id, login, nome, pts FROM public.usuarios_garra WHERE login=$1 AND ativo=true", login
    )
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    pts_atual = user["pts"] or 0
    pts_novo = max(0, pts_atual + ajuste)  # Não permite negativo

    # Atualizar pontos
    await db.execute(
        "UPDATE public.usuarios_garra SET pts=$1, atualizado_em=NOW() WHERE login=$2",
        pts_novo, login
    )

    # Registrar log do ajuste
    gestor_login = _auth.get("sub", "") or _auth.get("login", "")
    try:
        await db.execute("""
            INSERT INTO public.log_ajuste_pontos
            (usuario_login, usuario_nome, pts_antes, ajuste, pts_depois, motivo, ajustado_por, criado_em)
            VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
        """, login, user["nome"], pts_atual, ajuste, pts_novo, motivo, gestor_login)
    except Exception:
        # Tabela pode não existir ainda — cria na próxima migration
        pass

    return {
        "ok": True,
        "login": login,
        "pts_antes": pts_atual,
        "ajuste": ajuste,
        "pts_depois": pts_novo,
        "motivo": motivo
    }

@app.get("/checklist/modelos")
async def listar_modelos(db=Depends(get_db), _auth=Depends(verificar_token)):
    rows = await db.fetch("SELECT * FROM checklist.modelos WHERE ativo=TRUE ORDER BY label")
    result = []
    for r in rows:
        d = dict(r)
        d["questions"] = d["questions"] if isinstance(d["questions"],list) else json.loads(d["questions"] or "[]")
        d["steps"]     = d["steps"]     if isinstance(d["steps"],list)     else json.loads(d["steps"]     or "[]")
        result.append(d)
    return result

@app.post("/checklist/modelos")
async def salvar_modelo(cl: ChecklistModeloCreate, db=Depends(get_db), _auth=Depends(verificar_token)):
    existe = await db.fetchval("SELECT id FROM checklist.modelos WHERE cl_id=$1", cl.cl_id)
    if existe:
        await db.execute(
            "UPDATE checklist.modelos SET label=$1,icon=$2,descricao=$3,vehicle_cat=$4,is_default=$5,score_full=$6,score_nc=$7,score_obs=$8,score_ontime=$9,questions=$10,steps=$11 WHERE cl_id=$12",
            cl.label,cl.icon,cl.descricao,cl.vehicle_cat,cl.is_default,cl.score_full,cl.score_nc,cl.score_obs,cl.score_ontime,json.dumps(cl.questions),json.dumps(cl.steps),cl.cl_id
        )
    else:
        await db.execute(
            "INSERT INTO checklist.modelos (cl_id,label,icon,descricao,vehicle_cat,is_default,score_full,score_nc,score_obs,score_ontime,questions,steps) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)",
            cl.cl_id,cl.label,cl.icon,cl.descricao,cl.vehicle_cat,cl.is_default,cl.score_full,cl.score_nc,cl.score_obs,cl.score_ontime,json.dumps(cl.questions),json.dumps(cl.steps)
        )
    return {"ok": True}

@app.delete("/checklist/modelos/{cl_id}")
async def remover_modelo(cl_id: str, db=Depends(get_db), _auth=Depends(verificar_token)):
    await db.execute("UPDATE checklist.modelos SET ativo=FALSE WHERE cl_id=$1", cl_id)
    return {"ok": True}

@app.get("/checklist/envios")
async def listar_envios(usuario: Optional[str]=None, cl_id: Optional[str]=None, limit: int=100, db=Depends(get_db), _auth=Depends(verificar_token)):
    where, params = "WHERE arquivado=FALSE", []
    if usuario: params.append(usuario); where += f" AND usuario_login=${len(params)}"
    if cl_id:   params.append(cl_id);   where += f" AND cl_id=${len(params)}"
    params.append(limit)
    rows = await db.fetch(f"SELECT * FROM checklist.envios {where} ORDER BY enviado_em DESC LIMIT ${len(params)}", *params)
    result = []
    for r in rows:
        d = dict(r)
        d["meta"]      = d["meta"]      if isinstance(d["meta"],dict)      else json.loads(d["meta"]      or "{}")
        d["respostas"] = d["respostas"] if isinstance(d["respostas"],dict) else json.loads(d["respostas"] or "{}")
        d["respostas"] = _checklist_assinar_fotos_para_leitura(d["respostas"])
        result.append(d)
    return result

@app.post("/checklist/envios")
async def salvar_envio(e: EnvioCreate, db=Depends(get_db), _auth=Depends(verificar_token)):
    existe = await db.fetchval("SELECT id FROM checklist.envios WHERE envio_id=$1", e.envio_id)
    if existe: return {"ok": True, "duplicado": True}
    data = datetime.fromisoformat(e.enviado_em) if e.enviado_em else datetime.now()
    respostas_processadas = _checklist_extrair_fotos_para_storage(e.envio_id, dict(e.respostas))
    await db.execute(
        "INSERT INTO checklist.envios (envio_id,usuario_login,usuario_nome,cl_id,cl_label,meta,respostas,pts,tem_nc,total_nc,enviado_em) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)",
        e.envio_id,e.usuario_login,e.usuario_nome,e.cl_id,e.cl_label,json.dumps(e.meta),json.dumps(respostas_processadas),e.pts,e.tem_nc,e.total_nc,data
    )
    await db.execute(
        "UPDATE public.usuarios_garra SET pts=pts+$1, total_envios=total_envios+1, atualizado_em=NOW() WHERE login=$2",
        e.pts, e.usuario_login
    )
    return {"ok": True}

@app.patch("/checklist/envios/{envio_id}/arquivar")
async def arquivar_envio(envio_id: str, db=Depends(get_db), _auth=Depends(verificar_token)):
    await db.execute("UPDATE checklist.envios SET arquivado=TRUE WHERE envio_id=$1", envio_id)
    return {"ok": True}

@app.get("/frota")
async def listar_frota(db=Depends(get_db), _auth=Depends(verificar_token)):
    rows = await db.fetch(
        "SELECT DISTINCT ON (categoria, identificacao) * "
        "FROM checklist.frota WHERE ativo=TRUE "
        "ORDER BY categoria, identificacao, id"
    )
    return [dict(r) for r in rows]

@app.post("/frota")
async def salvar_frota(item: FrotaItem, db=Depends(get_db), _auth=Depends(verificar_token)):
    existe = await db.fetchval("SELECT id FROM checklist.frota WHERE categoria=$1 AND identificacao=$2", item.categoria, item.identificacao)
    if existe:
        await db.execute("UPDATE checklist.frota SET descricao=$1,ativo=TRUE WHERE categoria=$2 AND identificacao=$3", item.descricao,item.categoria,item.identificacao)
    else:
        await db.execute("INSERT INTO checklist.frota (categoria,identificacao,descricao) VALUES ($1,$2,$3)", item.categoria,item.identificacao,item.descricao)
    return {"ok": True}

@app.delete("/frota/{categoria}/{identificacao}")
async def remover_frota(categoria: str, identificacao: str, db=Depends(get_db), _auth=Depends(verificar_token)):
    await db.execute("UPDATE checklist.frota SET ativo=FALSE WHERE categoria=$1 AND identificacao=$2", categoria, identificacao)
    return {"ok": True}

@app.get("/logistica/motoristas")
async def listar_motoristas(db=Depends(get_db), _auth=Depends(verificar_token)):
    rows = await db.fetch("SELECT * FROM checklist.log_motoristas ORDER BY nome")
    return [dict(r) for r in rows]

@app.post("/logistica/motoristas")
async def salvar_motorista(m: LogMotoristaCreate, db=Depends(get_db), _auth=Depends(verificar_token)):
    existe = await db.fetchval("SELECT id FROM checklist.log_motoristas WHERE motor_id=$1", m.motor_id)
    if existe:
        await db.execute("UPDATE checklist.log_motoristas SET nome=$1,cpf=$2,cnh=$3,telefone=$4,status=$5,observacoes=$6,atualizado_em=NOW() WHERE motor_id=$7", m.nome,m.cpf,m.cnh,m.telefone,m.status,m.observacoes,m.motor_id)
    else:
        await db.execute("INSERT INTO checklist.log_motoristas (motor_id,nome,cpf,cnh,telefone,status,observacoes) VALUES ($1,$2,$3,$4,$5,$6,$7)", m.motor_id,m.nome,m.cpf,m.cnh,m.telefone,m.status,m.observacoes)
    return {"ok": True}

@app.delete("/logistica/motoristas/{motor_id}")
async def remover_motorista(motor_id: str, db=Depends(get_db), _auth=Depends(verificar_token)):
    await db.execute("DELETE FROM checklist.log_motoristas WHERE motor_id=$1", motor_id)
    return {"ok": True}

@app.get("/logistica/veiculos")
async def listar_veiculos(db=Depends(get_db), _auth=Depends(verificar_token)):
    rows = await db.fetch("SELECT * FROM checklist.log_veiculos ORDER BY car_id")
    result = []
    for r in rows:
        d = dict(r); d["extras"] = d["extras"] if isinstance(d["extras"],list) else json.loads(d["extras"] or "[]")
        result.append(d)
    return result

@app.post("/logistica/veiculos")
async def salvar_veiculo(v: LogVeiculoCreate, db=Depends(get_db), _auth=Depends(verificar_token)):
    existe = await db.fetchval("SELECT id FROM checklist.log_veiculos WHERE veiculo_id=$1", v.veiculo_id)
    if existe:
        await db.execute("UPDATE checklist.log_veiculos SET car_id=$1,placa=$2,modelo=$3,ano=$4,cor=$5,status=$6,extras=$7,observacoes=$8,atualizado_em=NOW() WHERE veiculo_id=$9", v.car_id,v.placa,v.modelo,v.ano,v.cor,v.status,json.dumps(v.extras),v.observacoes,v.veiculo_id)
    else:
        await db.execute("INSERT INTO checklist.log_veiculos (veiculo_id,car_id,placa,modelo,ano,cor,status,extras,observacoes) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)", v.veiculo_id,v.car_id,v.placa,v.modelo,v.ano,v.cor,v.status,json.dumps(v.extras),v.observacoes)
    return {"ok": True}

@app.delete("/logistica/veiculos/{veiculo_id}")
async def remover_veiculo(veiculo_id: str, db=Depends(get_db), _auth=Depends(verificar_token)):
    await db.execute("DELETE FROM checklist.log_veiculos WHERE veiculo_id=$1", veiculo_id)
    return {"ok": True}

@app.get("/logistica/registros")
async def listar_registros(limit: int=50, db=Depends(get_db), _auth=Depends(verificar_token)):
    rows = await db.fetch("SELECT * FROM checklist.log_registros ORDER BY data_hora DESC LIMIT $1", limit)
    result = []
    for r in rows:
        d = dict(r); d["carros"] = d["carros"] if isinstance(d["carros"],list) else json.loads(d["carros"] or "[]")
        result.append(d)
    return result

@app.post("/logistica/registros")
async def salvar_registro(r: LogRegistroCreate, db=Depends(get_db), _auth=Depends(verificar_token)):
    existe = await db.fetchval("SELECT id FROM checklist.log_registros WHERE registro_id=$1", r.registro_id)
    if existe:
        await db.execute("UPDATE checklist.log_registros SET responsavel=$1,data_hora=$2,carros=$3 WHERE registro_id=$4", r.responsavel,datetime.fromisoformat(r.data_hora),json.dumps(r.carros),r.registro_id)
    else:
        await db.execute("INSERT INTO checklist.log_registros (registro_id,responsavel,data_hora,carros) VALUES ($1,$2,$3,$4)", r.registro_id,r.responsavel,datetime.fromisoformat(r.data_hora),json.dumps(r.carros))
    return {"ok": True}

@app.delete("/logistica/registros/{registro_id}")
async def remover_registro(registro_id: str, db=Depends(get_db), _auth=Depends(verificar_token)):
    await db.execute("DELETE FROM checklist.log_registros WHERE registro_id=$1", registro_id)
    return {"ok": True}

# ══════════════════════════════════════════════════════════════
# ROTAS JARDINAGEM — prefixo /jardinagem
# ══════════════════════════════════════════════════════════════

# ── PAGES ─────────────────────────────────────────────────────
@app.get("/operacional/manifest.json")
async def operacional_manifest():
    """PWA manifest para o mobile operacional."""
    return {
        "name": "Garra Operacional",
        "short_name": "Garra Op",
        "start_url": "/operacional/mobile",
        "display": "standalone",
        "background_color": "#F0F4FF",
        "theme_color": "#1A2A5E",
        "icons": [
            {"src": "/static/icons/icon-192.png", "sizes": "192x192", "type": "image/png"},
            {"src": "/static/icons/icon-512.png", "sizes": "512x512", "type": "image/png"}
        ]
    }

@app.get("/operacional/mobile", response_class=HTMLResponse)
async def operacional_mobile():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "operacional", "operacional-mobile.html")
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Mobile operacional não encontrado")
    return open(path, encoding="utf-8").read()

@app.get("/admin", response_class=HTMLResponse)
async def admin_page():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "admin", "admin-app.html")
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Admin app não encontrado")
    return open(path, encoding="utf-8").read()

@app.get("/jardinagem", response_class=HTMLResponse)
@app.get("/jardinagem/", response_class=HTMLResponse)
async def jard_index():
    path = os.path.join(TEMPLATES_DIR, "desk-admin.html")
    return open(path, encoding="utf-8").read()

@app.get("/jardinagem/desktop")
async def jard_desktop_login():
    # Login unificado — redireciona para o admin (SSO abre desk-app direto)
    return RedirectResponse(url="/admin")

@app.get("/jardinagem/desktop-app", response_class=HTMLResponse)
async def jard_desktop_app():
    # Desktop app para Luana/Admin
    path = os.path.join(TEMPLATES_DIR, "desk-app.html")
    return open(path, encoding="utf-8").read()

@app.get("/jardinagem/mobile")
async def jard_mobile():
    # Login unificado — redireciona para o mobile (SSO abre pwa-app direto)
    return RedirectResponse(url="/mobile")

@app.get("/jardinagem/mobile-app", response_class=HTMLResponse)
async def jard_mobile_app():
    # Mobile PWA app para Arthur/Breno
    path = os.path.join(STATIC_DIR, "pwa-app.html")
    return open(path, encoding="utf-8").read()

@app.get("/jardinagem/pwa-login.html")
async def jard_pwa_login_html():
    # Login unificado — redireciona para o mobile
    return RedirectResponse(url="/mobile")

@app.get("/jardinagem/pwa-app.html", response_class=HTMLResponse)
async def jard_pwa_app_html():
    # Resolve redirect "./pwa-app.html" do pwa-login.html
    path = os.path.join(STATIC_DIR, "pwa-app.html")
    return open(path, encoding="utf-8").read()

@app.get("/jardinagem/manifest.json")
async def jard_manifest():
    return FileResponse(os.path.join(STATIC_DIR, "manifest.json"))

@app.get("/jardinagem/sw.js")
async def jard_sw():
    # sw.js na raiz de static/ (não em static/js/)
    return FileResponse(os.path.join(STATIC_DIR, "sw.js"),
                        headers={"Service-Worker-Allowed": "/jardinagem", "Cache-Control": "no-cache"})

# ── AUTH JARDINAGEM ───────────────────────────────────────────
@app.post("/jardinagem/api/login")
async def jard_login(request: Request):
    d = await request.json()
    email = (d.get("email") or "").strip().lower()
    senha = (d.get("senha") or "").encode()
    usuario = jard_query(
        "SELECT * FROM public.usuarios_garra WHERE (email=%s OR login=%s) AND ativo=true LIMIT 1",
        (email, email), fetch="one"
    )
    if not usuario or not bcrypt.checkpw(senha, usuario["senha_hash"].encode()):
        raise HTTPException(status_code=401, detail="Credenciais inválidas")
    token = gerar_token_jard(dict(usuario))
    return {"token": token, "nome": usuario["nome"], "perfil": usuario["perfil"]}

@app.get("/jardinagem/api/me")
async def jard_me(payload=Depends(verificar_token_jard)):
    return payload

@app.post("/jardinagem/api/logout")
async def jard_logout():
    return {"ok": True}

# ── MESES ─────────────────────────────────────────────────────
@app.get("/jardinagem/api/meses")
async def jard_list_meses(payload=Depends(exigir_acesso_jardinagem)):
    meses = jard_query("""
        SELECT m.*, COUNT(DISTINCT s.id) as total_semanas
        FROM jardinagem.meses m
        LEFT JOIN jardinagem.semanas s ON s.mes_id=m.id
        GROUP BY m.id ORDER BY m.ano DESC, m.mes DESC
    """)
    return [dict(r) for r in meses]

@app.delete("/jardinagem/api/meses/{mid}")
async def jard_del_mes(mid: int, payload=Depends(verificar_token_jard)):
    mes = jard_query("SELECT id FROM jardinagem.meses WHERE id=%s", (mid,), fetch="one")
    if not mes:
        raise HTTPException(status_code=404, detail="Mês não encontrado")
    semanas = jard_query("SELECT id FROM jardinagem.semanas WHERE mes_id=%s", (mid,))
    for s in semanas:
        pares = jard_query("SELECT id FROM jardinagem.pares WHERE semana_id=%s", (s["id"],))
        for p in pares:
            fotos = jard_query("SELECT storage_path FROM jardinagem.fotos WHERE par_id=%s", (p["id"],))
            paths = [f["storage_path"] for f in fotos if f["storage_path"]]
            if paths: storage_delete(paths)
            jard_query("DELETE FROM jardinagem.fotos WHERE par_id=%s", (p["id"],), fetch="none")
        jard_query("DELETE FROM jardinagem.pares WHERE semana_id=%s", (s["id"],), fetch="none")
        jard_query("DELETE FROM jardinagem.fila_sync WHERE semana_id=%s", (s["id"],), fetch="none")
        jard_query("DELETE FROM jardinagem.emails_enviados WHERE semana_id=%s", (s["id"],), fetch="none")
        jard_query("DELETE FROM jardinagem.relatorios_diarios WHERE semana_id=%s", (s["id"],), fetch="none")
    jard_query("DELETE FROM jardinagem.semanas WHERE mes_id=%s", (mid,), fetch="none")
    jard_query("DELETE FROM jardinagem.meses WHERE id=%s", (mid,), fetch="none")
    return {"ok": True}

@app.post("/jardinagem/api/meses")
async def jard_criar_mes(request: Request, payload=Depends(verificar_token_jard)):
    d = await request.json()
    ano, mes = int(d["ano"]), int(d["mes"])
    nomes = ["","Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"]
    label = d.get("label") or f"{nomes[mes]}/{ano}"
    exist = jard_query("SELECT id FROM jardinagem.meses WHERE ano=%s AND mes=%s", (ano,mes), fetch="one")
    ja_existia = False
    if exist:
        mes_id = exist["id"]
        ja_existia = True
    else:
        row = jard_query_id("INSERT INTO jardinagem.meses(ano,mes,label) VALUES(%s,%s,%s)", (ano,mes,label))
        mes_id = row["id"]
    sem_exist = jard_query("SELECT id FROM jardinagem.semanas WHERE mes_id=%s LIMIT 1", (mes_id,), fetch="one")
    if not sem_exist:
        semanas_do_mes(ano, mes, mes_id)
    mes_data = jard_query("SELECT * FROM jardinagem.meses WHERE id=%s", (mes_id,), fetch="one")
    result = dict(mes_data)
    result["ja_existia"] = ja_existia
    return result

@app.patch("/jardinagem/api/meses/{mid}")
async def jard_patch_mes(mid: int, request: Request, payload=Depends(verificar_token_jard)):
    d = await request.json()
    if "label" in d:
        jard_query("UPDATE jardinagem.meses SET label=%s WHERE id=%s", (d["label"], mid), fetch="none")
    return {"ok": True}

@app.get("/jardinagem/api/meses/{mid}")
async def jard_get_mes(mid: int, payload=Depends(verificar_token_jard)):
    from concurrent.futures import ThreadPoolExecutor
    m = jard_query("SELECT * FROM jardinagem.meses WHERE id=%s", (mid,), fetch="one")
    if not m: raise HTTPException(status_code=404, detail="Não encontrado")
    result = dict(m)
    # 1 query semanas
    sems = jard_query("SELECT * FROM jardinagem.semanas WHERE mes_id=%s ORDER BY ordem", (mid,))
    if not sems:
        result["semanas"] = []
        return result
    sem_ids = [s["id"] for s in sems]
    # 1 query todos os pares do mês (elimina N+1)
    placeholders = ",".join(["%s"] * len(sem_ids))
    pares_raw = jard_query(
        f"SELECT * FROM jardinagem.pares WHERE semana_id IN ({placeholders}) AND (ativo IS NULL OR ativo=true) ORDER BY semana_id, codigo_a",
        tuple(sem_ids)
    )
    par_ids = [p["id"] for p in pares_raw] if pares_raw else []
    # 1 query todas as fotos do mês (elimina N+1)
    fotos_raw = []
    if par_ids:
        ph2 = ",".join(["%s"] * len(par_ids))
        fotos_raw = jard_query(
            f"SELECT * FROM jardinagem.fotos WHERE par_id IN ({ph2})",
            tuple(par_ids)
        )
    # Gerar todas as URLs em paralelo
    paths_map = {f["id"]: f["storage_path"] for f in fotos_raw if f.get("storage_path")}
    urls = {}
    if paths_map:
        with ThreadPoolExecutor(max_workers=12) as ex:
            futures = {ex.submit(storage_url, path): fid for fid, path in paths_map.items()}
            for future, fid in futures.items():
                try: urls[fid] = future.result(timeout=10)
                except: urls[fid] = ""
    # Montar estrutura por par
    fotos_por_par = {}
    for f in fotos_raw:
        pid = f["par_id"]
        if pid not in fotos_por_par: fotos_por_par[pid] = []
        fd = dict(f)
        fd["url"] = urls.get(f["id"], "")
        fotos_por_par[pid].append(fd)
    # Montar estrutura por semana
    pares_por_sem = {}
    for p in pares_raw:
        sid = p["semana_id"]
        if sid not in pares_por_sem: pares_por_sem[sid] = []
        pd = dict(p)
        pd["fotos"] = fotos_por_par.get(p["id"], [])
        pares_por_sem[sid].append(pd)
    # Montar resultado final
    result["semanas"] = []
    for s in sems:
        sd = dict(s)
        sd["mes_id"] = mid
        sd["pares"] = pares_por_sem.get(s["id"], [])
        result["semanas"].append(sd)
    return result

# ── SEMANAS ───────────────────────────────────────────────────
@app.get("/jardinagem/api/semanas")
async def jard_listar_semanas(mes_id: int = None, payload=Depends(verificar_token_jard)):
    if not mes_id:
        hoje = date.today().isoformat()
        row = jard_query("""SELECT m.id FROM jardinagem.meses m
                           JOIN jardinagem.semanas s ON s.mes_id=m.id
                           WHERE s.data_ini<=%s AND s.data_fim>=%s LIMIT 1""", (hoje,hoje), fetch="one")
        if not row:
            row = jard_query("SELECT id FROM jardinagem.meses ORDER BY ano DESC, mes DESC LIMIT 1", fetch="one")
        mes_id = row["id"] if row else None
    if not mes_id:
        return {"ok": True, "semanas": []}
    rows = jard_query(
        "SELECT * FROM jardinagem.semanas WHERE mes_id=%s ORDER BY ordem",
        (mes_id,)
    )
    semanas = []
    for r in rows:
        s = dict(r)
        s["data_inicio"] = r["data_ini"].isoformat() if r["data_ini"] else ""
        s["data_fim"]    = r["data_fim"].isoformat() if r["data_fim"] else ""
        semanas.append(s)
    return {"ok": True, "semanas": semanas}

@app.get("/jardinagem/api/semanas/ativa")
async def jard_semana_ativa(payload=Depends(verificar_token_jard)):
    hoje = date.today().isoformat()
    row = jard_query("""SELECT s.*,m.id as mes_id,m.ano,m.mes,m.label as mes_label
                        FROM jardinagem.semanas s JOIN jardinagem.meses m ON m.id=s.mes_id
                        WHERE s.data_ini::date<=%s AND s.data_fim::date>=%s
                        AND s.status='aberta' LIMIT 1""", (hoje,hoje), fetch="one")
    if not row:
        row = jard_query("""SELECT s.*,m.id as mes_id,m.ano,m.mes,m.label as mes_label
                            FROM jardinagem.semanas s JOIN jardinagem.meses m ON m.id=s.mes_id
                            WHERE s.status='aberta'
                            ORDER BY s.id DESC LIMIT 1""", fetch="one")
    if not row:
        raise HTTPException(status_code=404, detail="Sem semana ativa")
    return dict(row)

@app.post("/jardinagem/api/semanas")
async def jard_criar_semana(request: Request, payload=Depends(verificar_token_jard)):
    d = await request.json()
    mes_id = d.get("mes_id"); label = (d.get("label") or "").strip(); ordem = d.get("ordem",0)
    if not mes_id or not label: raise HTTPException(status_code=400, detail="mes_id e label obrigatórios")
    row = jard_query_id("INSERT INTO jardinagem.semanas (mes_id,label,ordem,status) VALUES (%s,%s,%s,'aberta')", (mes_id,label,ordem))
    return dict(row)

@app.patch("/jardinagem/api/semanas/{sid}")
async def jard_patch_semana(sid: int, request: Request, payload=Depends(verificar_token_jard)):
    d = await request.json()
    for col in ["label","status","enviado_em"]:
        if col in d:
            jard_query(f"UPDATE jardinagem.semanas SET {col}=%s WHERE id=%s", (d[col],sid), fetch="none")
    return {"ok": True}

@app.delete("/jardinagem/api/semanas/{sid}")
async def jard_del_semana(sid: int, payload=Depends(verificar_token_jard)):
    pares = jard_query("SELECT id FROM jardinagem.pares WHERE semana_id=%s", (sid,))
    for p in pares:
        fotos = jard_query("SELECT storage_path FROM jardinagem.fotos WHERE par_id=%s", (p["id"],))
        paths = [f["storage_path"] for f in fotos if f["storage_path"]]
        if paths: storage_delete(paths)
        jard_query("DELETE FROM jardinagem.fotos WHERE par_id=%s", (p["id"],), fetch="none")
    jard_query("DELETE FROM jardinagem.pares WHERE semana_id=%s", (sid,), fetch="none")
    jard_query("DELETE FROM jardinagem.fila_sync WHERE semana_id=%s", (sid,), fetch="none")
    jard_query("DELETE FROM jardinagem.emails_enviados WHERE semana_id=%s", (sid,), fetch="none")
    jard_query("DELETE FROM jardinagem.relatorios_diarios WHERE semana_id=%s", (sid,), fetch="none")
    jard_query("DELETE FROM jardinagem.semanas WHERE id=%s", (sid,), fetch="none")
    return {"ok": True}

@app.get("/jardinagem/api/semanas/{sid}/status")
async def jard_status_semana(sid: int, payload=Depends(verificar_token_jard)):
    sem = jard_query("SELECT * FROM jardinagem.semanas WHERE id=%s", (sid,), fetch="one")
    if not sem: raise HTTPException(status_code=404, detail="Não encontrada")
    emails = jard_query("SELECT * FROM jardinagem.emails_enviados WHERE semana_id=%s ORDER BY enviado_em DESC", (sid,))
    tp = jard_query("SELECT COUNT(*) as n FROM jardinagem.pares WHERE semana_id=%s", (sid,), fetch="one")
    tf = jard_query("SELECT COUNT(*) as n FROM jardinagem.fotos f JOIN jardinagem.pares p ON p.id=f.par_id WHERE p.semana_id=%s", (sid,), fetch="one")
    tr = jard_query("SELECT COUNT(*) as n FROM jardinagem.relatorios_diarios WHERE semana_id=%s", (sid,), fetch="one")
    return {"semana":dict(sem),"total_pares":tp["n"],"total_fotos":tf["n"],"total_relatorios":tr["n"],"emails":[dict(e) for e in emails]}

# ── PARES ─────────────────────────────────────────────────────
@app.get("/jardinagem/api/pares")
async def jard_listar_pares(semana_id: int = None, payload=Depends(verificar_token_jard)):
    if not semana_id:
        return {"ok": False, "error": "semana_id obrigatório"}
    pares_raw = jard_query(
        "SELECT * FROM jardinagem.pares WHERE semana_id=%s AND (ativo IS NULL OR ativo=true) ORDER BY codigo_a",
        (semana_id,)
    )
    pares = []
    for p in pares_raw:
        pd = dict(p)
        fotos = jard_query("SELECT * FROM jardinagem.fotos WHERE par_id=%s", (p["id"],))
        pd["fotos"] = []
        for f in fotos:
            fd = dict(f)
            fd["url"] = storage_url(f["storage_path"]) if f["storage_path"] else ""
            pd["fotos"].append(fd)
        pares.append(pd)
    return {"ok": True, "pares": pares}

@app.post("/jardinagem/api/pares")
async def jard_criar_par(request: Request, payload=Depends(verificar_token_jard)):
    d = await request.json()
    # ── Reserva ATÔMICA do próximo código (evita duplicação em salvamento paralelo) ──
    # Uma única UPDATE ... RETURNING: o config.next_code é elevado ao maior entre
    # (ele mesmo) e (MAX(codigo_d ativo)+1), depois avançado +2, e retorna o código
    # reservado. Por ser atômico no Postgres, dois pares simultâneos pegam números
    # diferentes — elimina a race condition que duplicava códigos.
    reserva = jard_query(
        """
        UPDATE jardinagem.config c
        SET valor = (
            GREATEST(
                (c.valor)::int,
                COALESCE((SELECT MAX(codigo_d)+1 FROM jardinagem.pares
                          WHERE (ativo IS NULL OR ativo=true)), 6050)
            ) + 2
        )::text
        WHERE c.chave = 'next_code'
        RETURNING (c.valor)::int - 2 AS cod
        """,
        fetch="one"
    )
    if reserva and reserva.get("cod") is not None:
        cod = int(reserva["cod"])
    else:
        # Fallback: config inexistente — calcula direto e cria a chave
        ultimo = jard_query(
            "SELECT MAX(codigo_d) as max_cod FROM jardinagem.pares WHERE (ativo IS NULL OR ativo=true)",
            fetch="one"
        )
        cod = max(int(ultimo.get("max_cod") or 6049), 6049) + 1
        jard_query("INSERT INTO jardinagem.config (chave,valor) VALUES ('next_code',%s) ON CONFLICT (chave) DO UPDATE SET valor=EXCLUDED.valor",
                   (str(cod + 2),), fetch="none")

    row = jard_query_id("INSERT INTO jardinagem.pares (semana_id,codigo_a,codigo_d,local_nome,data_label,ordem,ativo) VALUES (%s,%s,%s,%s,%s,%s,true)",
                        (d["semana_id"],cod,cod+1,d.get("local_nome",""),d.get("data_label",""),d.get("ordem",0)))
    return dict(row)

@app.patch("/jardinagem/api/pares/{pid}")
async def jard_patch_par(pid: int, request: Request, payload=Depends(verificar_token_jard)):
    d = await request.json()
    for col in ["local_nome","ordem","semana_id","data_label"]:
        if col in d:
            jard_query(f"UPDATE jardinagem.pares SET {col}=%s WHERE id=%s", (d[col],pid), fetch="none")
    return {"ok": True}

@app.delete("/jardinagem/api/pares/{pid}")
async def jard_del_par(pid: int, payload=Depends(verificar_token_jard)):
    # Soft delete: marcar par como inativo (campo ativo=false)
    # Fotos não são deletadas — seguem vinculadas mas não aparecem
    # next_code NÃO é alterado — sequência de códigos é imutável
    jard_query("UPDATE jardinagem.pares SET ativo=false WHERE id=%s", (pid,), fetch="none")
    return {"ok": True}

# ── FOTOS ─────────────────────────────────────────────────────
@app.patch("/jardinagem/api/fotos/{fid}")
async def jard_patch_foto(fid: int, request: Request, payload=Depends(verificar_token_jard)):
    d = await request.json()
    if "tipo" in d and d["tipo"] in ("antes", "depois"):
        jard_query("UPDATE jardinagem.fotos SET tipo=%s WHERE id=%s", (d["tipo"], fid), fetch="none")
    return {"ok": True}

@app.post("/jardinagem/api/fotos/avulsa")
async def jard_foto_avulsa(
    par_id: int = Form(...), tipo: str = Form(...),
    foto: UploadFile = File(...), payload=Depends(verificar_token_jard)
):
    import logging
    log = logging.getLogger(__name__)
    try:
        conteudo = await foto.read()
        if not conteudo:
            raise HTTPException(status_code=400, detail="Arquivo vazio")
        dados = comprimir_imagem(conteudo)
        path  = storage_upload(dados, f"jardinagem/{datetime.now().strftime('%Y/%m')}/{uuid.uuid4().hex}.jpg")
        antiga = jard_query("SELECT id,storage_path FROM jardinagem.fotos WHERE par_id=%s AND tipo=%s", (par_id,tipo), fetch="one")
        if antiga:
            if antiga.get("storage_path"):
                storage_delete([antiga["storage_path"]])
            jard_query("DELETE FROM jardinagem.fotos WHERE id=%s", (antiga["id"],), fetch="none")
        row = jard_query_id(
            "INSERT INTO jardinagem.fotos (par_id,tipo,origem,enviado_por,storage_path,filename_orig,sincronizado) VALUES (%s,%s,'desktop',%s,%s,%s,true)",
            (par_id,tipo,str(payload["sub"]),path,foto.filename or "foto.jpg")
        )
        fd = dict(row); fd["url"] = storage_url(path)
        return fd
    except HTTPException:
        raise
    except Exception as e:
        log.error(f"fotos/avulsa erro: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Erro ao salvar foto: {str(e)}")

@app.post("/jardinagem/api/fotos/mobile")
async def jard_foto_mobile(
    semana_id: str = Form(...),
    local_nome: str = Form(""),
    tipo: str = Form("antes"),
    par_id: Optional[str] = Form(None),
    offline_id: Optional[str] = Form(None),
    foto: UploadFile = File(...),
    payload=Depends(verificar_token_jard)
):
    """Upload de foto pelo mobile (câmera ou galeria)."""
    import logging
    log = logging.getLogger(__name__)
    try:
        sid = None
        if semana_id and semana_id != "ativa":
            try: sid = int(semana_id)
            except: pass

        if not sid:
            import datetime as dt
            hoje = dt.date.today().isoformat()
            row = jard_query("""
                SELECT id FROM jardinagem.semanas
                WHERE data_ini <= %s AND data_fim >= %s LIMIT 1
            """, (hoje, hoje), fetch="one")
            if row: sid = row["id"]

        if not sid:
            raise HTTPException(status_code=400, detail="Sem semana ativa. Crie um mês primeiro.")

        pid = None
        if par_id and par_id not in ("null","undefined",""):
            try: pid = int(par_id)
            except: pass

        if not pid:
            row = jard_query_id(
                "INSERT INTO jardinagem.pares (semana_id,codigo_a,codigo_d,local_nome,data_label,ordem) VALUES (%s,%s,%s,%s,%s,%s)",
                (sid, 0, 0, local_nome or "", "", 99)
            )
            pid = row["id"]
            cod = next_code(2)
            jard_query("UPDATE jardinagem.pares SET codigo_a=%s, codigo_d=%s WHERE id=%s",
                      (cod, cod+1, pid), fetch="none")

        if offline_id:
            exist = jard_query(
                "SELECT id FROM jardinagem.fotos WHERE offline_id=%s", (offline_id,), fetch="one"
            )
            if exist:
                return {"ok": True, "foto_id": exist["id"], "duplicado": True}

        conteudo = await foto.read()
        if not conteudo:
            raise HTTPException(status_code=400, detail="Arquivo vazio")

        dados = comprimir_imagem(conteudo)
        path  = storage_upload(dados, f"jardinagem/{uuid.uuid4().hex}.jpg")

        antiga = jard_query(
            "SELECT id, storage_path FROM jardinagem.fotos WHERE par_id=%s AND tipo=%s",
            (pid, tipo), fetch="one"
        )
        if antiga:
            if antiga.get("storage_path"): storage_delete([antiga["storage_path"]])
            jard_query("DELETE FROM jardinagem.fotos WHERE id=%s", (antiga["id"],), fetch="none")

        row = jard_query_id("""
            INSERT INTO jardinagem.fotos
            (par_id, tipo, origem, enviado_por, storage_path, filename_orig, sincronizado, offline_id)
            VALUES (%s, %s, 'mobile', %s, %s, %s, true, %s)
        """, (pid, tipo, str(payload["sub"]), path, foto.filename or "foto.jpg", offline_id))

        fd = dict(row)
        fd["url"] = storage_url(path)
        fd["par_id"] = pid
        return {"ok": True, "foto_id": fd["id"], "storage_path": path, "url": fd["url"], "par_id": pid}

    except HTTPException:
        raise
    except Exception as e:
        log.error(f"fotos/mobile erro: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Erro: {str(e)}")

@app.delete("/jardinagem/api/fotos/{fid}")
async def jard_del_foto(fid: int, payload=Depends(verificar_token_jard)):
    f = jard_query("SELECT storage_path FROM jardinagem.fotos WHERE id=%s", (fid,), fetch="one")
    if f: storage_delete([f["storage_path"]]); jard_query("DELETE FROM jardinagem.fotos WHERE id=%s", (fid,), fetch="none")
    return {"ok": True}

@app.get("/jardinagem/api/fotos/{fid}/url")
async def jard_url_foto(fid: int, payload=Depends(verificar_token_jard)):
    f = jard_query("SELECT storage_path FROM jardinagem.fotos WHERE id=%s", (fid,), fetch="one")
    if not f: raise HTTPException(status_code=404, detail="Não encontrado")
    return {"url": storage_url(f["storage_path"])}

# ── RELATÓRIO DIÁRIO ──────────────────────────────────────────
@app.post("/jardinagem/api/relatorios/km")
async def jard_criar_km(request: Request, payload=Depends(verificar_token_jard)):
    d = await request.json()
    semana_id = d.get("semana_id")
    if not semana_id:
        hoje = date.today().isoformat()
        row = jard_query("SELECT id FROM jardinagem.semanas WHERE data_ini<=%s AND data_fim>=%s LIMIT 1", (hoje,hoje), fetch="one")
        if not row: raise HTTPException(status_code=404, detail="Sem semana ativa")
        semana_id = row["id"]
    local_nome  = (d.get("local_nome") or "").strip()
    km_ini      = d.get("km_inicial"); km_fin = d.get("km_final")
    if not local_nome: raise HTTPException(status_code=400, detail="local_nome obrigatório")
    if km_ini is None or km_fin is None: raise HTTPException(status_code=400, detail="km_inicial e km_final obrigatórios")
    if float(km_fin) < float(km_ini): raise HTTPException(status_code=400, detail="km_final não pode ser menor que km_inicial")
    offline_id = d.get("offline_id")
    if offline_id:
        exist = jard_query("SELECT id FROM jardinagem.relatorios_diarios WHERE offline_id=%s", (offline_id,), fetch="one")
        if exist: return {"ok": True, "duplicado": True, "id": exist["id"]}
    row = jard_query_id("""INSERT INTO jardinagem.relatorios_diarios
        (semana_id,usuario_id,data,local_nome,km_inicial,km_final,hora_inicio,hora_fim,observacao,offline_id)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (semana_id,payload["sub"],d.get("data",date.today().isoformat()),local_nome,
         float(km_ini),float(km_fin),d.get("hora_inicio"),d.get("hora_fim"),d.get("observacao",""),offline_id))
    return {"ok": True, "id": row["id"]}

@app.patch("/jardinagem/api/relatorios/{km_id}")
async def jard_editar_km(km_id: int, request: Request, payload=Depends(verificar_token_jard)):
    d = await request.json()
    local_nome  = (d.get("local_nome") or "").strip()
    km_ini      = d.get("km_inicial"); km_fin = d.get("km_final")
    if not local_nome: raise HTTPException(status_code=400, detail="local_nome obrigatório")
    if km_ini is None or km_fin is None: raise HTTPException(status_code=400, detail="km_inicial e km_final obrigatórios")
    if float(km_fin) < float(km_ini): raise HTTPException(status_code=400, detail="km_final não pode ser menor que km_inicial")
    
    # Atualiza o registro
    jard_query("""UPDATE jardinagem.relatorios_diarios 
        SET data=%s, local_nome=%s, km_inicial=%s, km_final=%s, 
            hora_inicio=%s, hora_fim=%s, observacao=%s
        WHERE id=%s""",
        (d.get("data",date.today().isoformat()), local_nome,
         float(km_ini), float(km_fin),
         d.get("hora_inicio"), d.get("hora_fim"), d.get("observacao",""),
         km_id), fetch="none")
    return {"ok": True, "id": km_id}

@app.delete("/jardinagem/api/relatorios/{km_id}")
async def jard_deletar_km(km_id: int, payload=Depends(verificar_token_jard)):
    jard_query("DELETE FROM jardinagem.relatorios_diarios WHERE id=%s", (km_id,), fetch="none")
    return {"ok": True, "id": km_id}

@app.get("/jardinagem/api/historico/hoje")
async def jard_historico_hoje(semana_id: Optional[int]=None, payload=Depends(verificar_token_jard)):
    hoje = date.today().isoformat()
    if semana_id:
        fotos_raw = jard_query("""SELECT f.id,f.tipo,f.storage_path,f.filename_orig,p.local_nome,f.criado_em
            FROM jardinagem.fotos f JOIN jardinagem.pares p ON p.id=f.par_id
            WHERE p.semana_id=%s AND f.enviado_por=%s AND DATE(f.criado_em)=%s ORDER BY f.criado_em DESC""",
            (semana_id,payload["sub"],hoje))
        km_raw = jard_query("""SELECT id,data,local_nome,km_inicial,km_final,hora_inicio,hora_fim,observacao
            FROM jardinagem.relatorios_diarios WHERE semana_id=%s AND usuario_id=%s AND data=%s ORDER BY criado_em DESC""",
            (semana_id,payload["sub"],hoje))
    else:
        fotos_raw = jard_query("""SELECT f.id,f.tipo,f.storage_path,f.filename_orig,p.local_nome,f.criado_em
            FROM jardinagem.fotos f JOIN jardinagem.pares p ON p.id=f.par_id
            WHERE f.enviado_por=%s AND DATE(f.criado_em)=%s ORDER BY f.criado_em DESC""",
            (payload["sub"],hoje))
        km_raw = jard_query("""SELECT id,data,local_nome,km_inicial,km_final,hora_inicio,hora_fim,observacao
            FROM jardinagem.relatorios_diarios WHERE usuario_id=%s AND data=%s ORDER BY criado_em DESC""",
            (payload["sub"],hoje))
    # Gerar URLs das fotos em paralelo
    from concurrent.futures import ThreadPoolExecutor
    fotos_list = [dict(f) for f in fotos_raw]
    paths_hoje = [(i, f["storage_path"]) for i, f in enumerate(fotos_list) if f.get("storage_path")]
    urls_hoje = {}
    if paths_hoje:
        with ThreadPoolExecutor(max_workers=8) as ex:
            futures = {ex.submit(storage_url, path): i for i, path in paths_hoje}
            for future, i in futures.items():
                try: urls_hoje[i] = future.result(timeout=10)
                except: urls_hoje[i] = ""
    fotos = []
    for i, f in enumerate(fotos_list):
        f["url"] = urls_hoje.get(i, "") if f.get("storage_path") else ""
        f["criado_em"] = f["criado_em"].isoformat() if f.get("criado_em") else ""
        fotos.append(f)
    km_list = []; km_total = 0.0
    for r in km_raw:
        rd = dict(r)
        ini = float(r["km_inicial"] or 0); fin = float(r["km_final"] or 0)
        rd["km_percorrido"] = round(fin-ini,1); rd["km_inicial"] = ini; rd["km_final"] = fin
        rd["hora_inicio"] = str(r["hora_inicio"]) if r["hora_inicio"] else ""
        rd["hora_fim"]    = str(r["hora_fim"])    if r["hora_fim"]    else ""
        km_total += rd["km_percorrido"]; km_list.append(rd)
    return {"data":hoje,"fotos":fotos,"km":km_list,"km_total":round(km_total,1)}

# ── CONFIG ────────────────────────────────────────────────────
@app.get("/jardinagem/api/inicio")
async def jard_inicio(payload=Depends(verificar_token_jard)):
    """Rota de carregamento rápido — retorna semana ativa + pares + config em 1 chamada."""
    hoje = date.today().isoformat()
    # 1. Semana ativa
    semana = jard_query("""SELECT s.*,m.id as mes_id,m.ano,m.mes,m.label as mes_label
                        FROM jardinagem.semanas s JOIN jardinagem.meses m ON m.id=s.mes_id
                        WHERE s.data_ini::date<=%s AND s.data_fim::date>=%s
                        AND s.status='aberta' LIMIT 1""", (hoje,hoje), fetch="one")
    if not semana:
        semana = jard_query("""SELECT s.*,m.id as mes_id,m.ano,m.mes,m.label as mes_label
                            FROM jardinagem.semanas s JOIN jardinagem.meses m ON m.id=s.mes_id
                            WHERE s.status='aberta'
                            ORDER BY s.id DESC LIMIT 1""", fetch="one")
    if not semana:
        return {"semana": None, "pares": [], "next_code": 6050}
    sid = semana["id"]
    # 2. Pares da semana (com fotos)
    pares = jard_query("""SELECT p.id,p.codigo_a,p.codigo_d,p.local_nome,p.ordem
                          FROM jardinagem.pares p
                          WHERE p.semana_id=%s AND (p.ativo IS NULL OR p.ativo=true)
                          ORDER BY p.codigo_a""", (sid,))
    fotos = jard_query("""SELECT f.id,f.par_id,f.tipo,f.storage_path
                          FROM jardinagem.fotos f
                          JOIN jardinagem.pares p ON p.id=f.par_id
                          WHERE p.semana_id=%s AND (p.ativo IS NULL OR p.ativo=true)""", (sid,))
    fotos_por_par = {}
    for f in fotos:
        pid = f["par_id"]
        if pid not in fotos_por_par: fotos_por_par[pid] = []
        fotos_por_par[pid].append({"id":f["id"],"tipo":f["tipo"],"storage_path":f["storage_path"]})
    pares_com_fotos = []
    for p in pares:
        pd = dict(p)
        pd["fotos"] = fotos_por_par.get(p["id"], [])
        pares_com_fotos.append(pd)
    # 3. Config (next_code)
    cfg = jard_query("SELECT valor FROM jardinagem.config WHERE chave='next_code'", fetch="one")
    next_code = int(cfg["valor"]) if cfg else 6050
    return {"semana": dict(semana), "pares": pares_com_fotos, "next_code": next_code}

@app.get("/jardinagem/api/config")
async def jard_config(payload=Depends(verificar_token_jard)):
    rows = jard_query("SELECT * FROM jardinagem.config")
    return {r["chave"]: r["valor"] for r in rows}

@app.get("/jardinagem/api/clientes")
async def jard_clientes(payload=Depends(verificar_token_jard)):
    rows = jard_query("SELECT id,nome FROM public.clientes_garra WHERE ativo=true")
    return [dict(r) for r in rows]

# ── PREVIEW RELATÓRIO ─────────────────────────────────────────
@app.get("/jardinagem/api/km/mes/{mes_id}")
async def jard_km_mes(mes_id: int, payload=Depends(verificar_token_jard)):
    """Retorna todos os KMs do mês em 1 chamada — evita N chamadas /preview."""
    kms_raw = jard_query("""
        SELECT r.id, r.data, r.local_nome, r.km_inicial, r.km_final,
               r.hora_inicio, r.hora_fim, r.observacao, r.responsavel,
               u.nome as responsavel_nome
        FROM jardinagem.relatorios_diarios r
        JOIN jardinagem.semanas s ON s.id = r.semana_id
        JOIN public.usuarios_garra u ON u.id = r.usuario_id
        WHERE s.mes_id = %s
        ORDER BY r.data, r.criado_em
    """, (mes_id,))
    kms = [{"id": r["id"],
            "data": r["data"].strftime("%d/%m/%Y") if r["data"] else "",
            "local_nome": r["local_nome"] or "",
            "km_inicial": float(r["km_inicial"] or 0),
            "km_final": float(r["km_final"] or 0),
            "hora_inicio": str(r["hora_inicio"]) if r["hora_inicio"] else "",
            "hora_fim": str(r["hora_fim"]) if r["hora_fim"] else "",
            "observacao": r["observacao"] or "",
            "responsavel": r["responsavel_nome"] or r["responsavel"] or ""
            } for r in kms_raw]
    return {"mes_id": mes_id, "relatorios": kms}

@app.get("/jardinagem/api/relatorios/{semana_id}/preview")
async def jard_preview(semana_id: int, payload=Depends(verificar_token_jard)):
    from concurrent.futures import ThreadPoolExecutor
    sem = jard_query("SELECT * FROM jardinagem.semanas WHERE id=%s", (semana_id,), fetch="one")
    if not sem: raise HTTPException(status_code=404, detail="Semana não encontrada")
    # 1 query pares + 1 query fotos (elimina N+1)
    pares_raw = jard_query("SELECT * FROM jardinagem.pares WHERE semana_id=%s AND (ativo IS NULL OR ativo=true) ORDER BY codigo_a", (semana_id,))
    fotos_raw = jard_query("""SELECT f.* FROM jardinagem.fotos f
        JOIN jardinagem.pares p ON p.id=f.par_id
        WHERE p.semana_id=%s AND (p.ativo IS NULL OR p.ativo=true)""", (semana_id,))
    fotos_por_par = {}
    for f in fotos_raw:
        pid = f["par_id"]
        if pid not in fotos_por_par: fotos_por_par[pid] = {}
        fotos_por_par[pid][f["tipo"]] = f
    # Coletar paths para gerar URLs em paralelo
    paths_map = {}
    for p in pares_raw:
        pid = p["id"]
        fp = fotos_por_par.get(pid, {})
        fa = fp.get("antes"); fd = fp.get("depois")
        if fa and fa.get("storage_path"): paths_map[f"{pid}_antes"] = fa["storage_path"]
        if fd and fd.get("storage_path"): paths_map[f"{pid}_depois"] = fd["storage_path"]
    # Gerar todas as URLs em paralelo
    urls = {}
    if paths_map:
        with ThreadPoolExecutor(max_workers=12) as ex:
            futures = {ex.submit(storage_url, path): key for key, path in paths_map.items()}
            for future, key in futures.items():
                try: urls[key] = future.result(timeout=10)
                except: urls[key] = ""
    pares = []
    for p in pares_raw:
        pid = p["id"]
        fp = fotos_por_par.get(pid, {})
        fa = fp.get("antes"); fd = fp.get("depois")
        pares.append({"id":pid,"codigo_a":p["codigo_a"],"codigo_d":p["codigo_d"],"local_nome":p["local_nome"] or "",
                      "foto_antes":bool(fa),"foto_depois":bool(fd),
                      "url_antes":urls.get(f"{pid}_antes",""),
                      "url_depois":urls.get(f"{pid}_depois","")})
    kms_raw = jard_query("""SELECT r.*,u.nome as responsavel_nome FROM jardinagem.relatorios_diarios r
        JOIN public.usuarios_garra u ON u.id=r.usuario_id WHERE r.semana_id=%s ORDER BY r.data,r.criado_em""", (semana_id,))
    kms = [{"id":r["id"],"data":r["data"].strftime("%d/%m/%Y") if r["data"] else "","local_nome":r["local_nome"] or "",
            "km_inicial":float(r["km_inicial"] or 0),"km_final":float(r["km_final"] or 0),
            "hora_inicio":str(r["hora_inicio"]) if r["hora_inicio"] else "",
            "hora_fim":str(r["hora_fim"]) if r["hora_fim"] else "",
            "observacao":r["observacao"] or "","responsavel":r["responsavel_nome"] or ""} for r in kms_raw]
    return {"semana_id":semana_id,"label":sem["label"],"pares":pares,"relatorios":kms,
            "total_pares":len(pares),"pares_completos":sum(1 for p in pares if p["foto_antes"] and p["foto_depois"]),"total_km":len(kms)}

# ── HELPERS NOME DE ARQUIVO ───────────────────────────────────
_MESES_PT = {1:"Jan",2:"Fev",3:"Mar",4:"Abr",5:"Mai",6:"Jun",
             7:"Jul",8:"Ago",9:"Set",10:"Out",11:"Nov",12:"Dez"}

def nome_arquivo_semana(sem, tipo: str) -> str:
    """Gera nome legível: relatorio-fotos-jun2026-semana1.xlsx"""
    import re
    # Extrair número da semana do label
    num = "?"
    try:
        m = re.search(r'Semana\s*(\d+)', sem.get("label") or "", re.IGNORECASE)
        if m: num = m.group(1)
    except: pass
    # Extrair mês e ano — tenta data_ini primeiro, depois extrai do label
    mes_abr, ano = "???", "????"
    try:
        di = sem.get("data_ini")
        if di and hasattr(di, "month"):
            mes_abr = _MESES_PT.get(di.month, f"{di.month:02d}").lower()
            ano = str(di.year)
        else:
            # Extrai do label: "Semana 1 — 01/06/2026 ..."
            dm = re.search(r'(\d{2})/(\d{2})/(\d{4})', sem.get("label") or "")
            if dm:
                mes_abr = _MESES_PT.get(int(dm.group(2)), dm.group(2)).lower()
                ano = dm.group(3)
    except: pass
    return f"relatorio-{tipo.lower()}-{mes_abr}{ano}-semana{num}.xlsx"

# ── DOWNLOAD EXCEL ────────────────────────────────────────────
@app.get("/jardinagem/api/relatorios/{semana_id}/fotos")
async def jard_excel_fotos(semana_id: int, payload=Depends(verificar_token_jard)):
    import sys; sys.path.insert(0, os.path.join(JARD_DIR))
    from gerar_relatorio import gerar_relatorio_fotos
    sem = jard_query("SELECT * FROM jardinagem.semanas WHERE id=%s", (semana_id,), fetch="one")
    if not sem: raise HTTPException(status_code=404, detail="Semana não encontrada")
    semana_dict = {"label":sem["label"],"data_ini":sem["data_ini"].strftime("%d/%m/%Y") if sem["data_ini"] else "","data_fim":sem["data_fim"].strftime("%d/%m/%Y") if sem["data_fim"] else ""}
    pares_raw = jard_query("SELECT * FROM jardinagem.pares WHERE semana_id=%s AND (ativo IS NULL OR ativo=true) ORDER BY codigo_a", (semana_id,))
    # 1 query para todas as fotos (elimina N+1)
    fotos_raw = jard_query("""SELECT f.* FROM jardinagem.fotos f
        JOIN jardinagem.pares p ON p.id=f.par_id
        WHERE p.semana_id=%s AND (p.ativo IS NULL OR p.ativo=true)""", (semana_id,))
    fotos_por_par = {}
    for f in fotos_raw:
        pid = f["par_id"]
        if pid not in fotos_por_par: fotos_por_par[pid] = {}
        fotos_por_par[pid][f["tipo"]] = dict(f)
    pares = []
    for p in pares_raw:
        fp = fotos_por_par.get(p["id"], {})
        pares.append({"codigo_a":p["codigo_a"],"codigo_d":p["codigo_d"],"local_nome":p["local_nome"] or "",
                      "foto_antes":fp.get("antes"), "foto_depois":fp.get("depois")})
    buf = gerar_relatorio_fotos(semana_dict, pares, SUPABASE_URL, SUPABASE_SERVICE_KEY)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition":f'attachment; filename="{nome_arquivo_semana(sem, "Fotos")}"'})

@app.get("/jardinagem/api/relatorios/{semana_id}/km")
async def jard_excel_km(semana_id: int, payload=Depends(verificar_token_jard)):
    import sys; sys.path.insert(0, os.path.join(JARD_DIR))
    from gerar_relatorio import gerar_relatorio_km
    sem = jard_query("SELECT * FROM jardinagem.semanas WHERE id=%s", (semana_id,), fetch="one")
    if not sem: raise HTTPException(status_code=404, detail="Semana não encontrada")
    semana_dict = {"label":sem["label"],"data_ini":sem["data_ini"].strftime("%d/%m/%Y") if sem["data_ini"] else "","data_fim":sem["data_fim"].strftime("%d/%m/%Y") if sem["data_fim"] else ""}
    kms_raw = jard_query("""SELECT r.*,u.nome as responsavel_nome FROM jardinagem.relatorios_diarios r
        JOIN public.usuarios_garra u ON u.id=r.usuario_id WHERE r.semana_id=%s ORDER BY r.data,r.criado_em""", (semana_id,))
    relatorios = [{"data":r["data"].strftime("%d/%m/%Y") if r["data"] else "","local":r["local_nome"] or "",
                   "km_ini":float(r["km_inicial"] or 0),"km_fin":float(r["km_final"] or 0),
                   "hr_ini":str(r["hora_inicio"]) if r["hora_inicio"] else "","hr_fim":str(r["hora_fim"]) if r["hora_fim"] else "",
                   "obs":r["observacao"] or "","responsavel":r["responsavel_nome"] or ""} for r in kms_raw]
    buf = gerar_relatorio_km(semana_dict, relatorios)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition":f'attachment; filename="{nome_arquivo_semana(sem, "KM")}"'})

@app.post("/jardinagem/api/relatorios/{semana_id}/enviar")
async def jard_enviar_email(semana_id: int, payload=Depends(verificar_token_jard)):
    if not all([MAIL_USERNAME, MAIL_PASSWORD, MAIL_DESTINO]):
        raise HTTPException(status_code=400, detail="Email não configurado")
    import sys; sys.path.insert(0, os.path.join(JARD_DIR))
    from gerar_relatorio import gerar_relatorio_fotos, gerar_relatorio_km
    sem = jard_query("SELECT * FROM jardinagem.semanas WHERE id=%s", (semana_id,), fetch="one")
    if not sem: raise HTTPException(status_code=404, detail="Semana não encontrada")
    semana_dict = {"label":sem["label"],"data_ini":sem["data_ini"].strftime("%d/%m/%Y") if sem["data_ini"] else "","data_fim":sem["data_fim"].strftime("%d/%m/%Y") if sem["data_fim"] else ""}
    pares_raw = jard_query("SELECT * FROM jardinagem.pares WHERE semana_id=%s AND (ativo IS NULL OR ativo=true) ORDER BY codigo_a", (semana_id,))
    # 1 query para todas as fotos (elimina N+1)
    fotos_raw_email = jard_query("""SELECT f.* FROM jardinagem.fotos f
        JOIN jardinagem.pares p ON p.id=f.par_id
        WHERE p.semana_id=%s AND (p.ativo IS NULL OR p.ativo=true)""", (semana_id,))
    fotos_por_par_email = {}
    for f in fotos_raw_email:
        pid = f["par_id"]
        if pid not in fotos_por_par_email: fotos_por_par_email[pid] = {}
        fotos_por_par_email[pid][f["tipo"]] = dict(f)
    pares = []
    for p in pares_raw:
        fp = fotos_por_par_email.get(p["id"], {})
        pares.append({"codigo_a":p["codigo_a"],"codigo_d":p["codigo_d"],"local_nome":p["local_nome"] or "",
                      "foto_antes":fp.get("antes"), "foto_depois":fp.get("depois")})
    kms_raw = jard_query("""SELECT r.*,u.nome as responsavel_nome FROM jardinagem.relatorios_diarios r
        JOIN public.usuarios_garra u ON u.id=r.usuario_id WHERE r.semana_id=%s ORDER BY r.data,r.criado_em""", (semana_id,))
    relatorios = [{"data":r["data"].strftime("%d/%m/%Y") if r["data"] else "","local":r["local_nome"] or "",
                   "km_ini":float(r["km_inicial"] or 0),"km_fin":float(r["km_final"] or 0),
                   "hr_ini":str(r["hora_inicio"]) if r["hora_inicio"] else "","hr_fim":str(r["hora_fim"]) if r["hora_fim"] else "",
                   "obs":r["observacao"] or "","responsavel":r["responsavel_nome"] or ""} for r in kms_raw]
    try:
        buf_fotos = gerar_relatorio_fotos(semana_dict, pares, SUPABASE_URL, SUPABASE_SERVICE_KEY)
        buf_km    = gerar_relatorio_km(semana_dict, relatorios)
        corpo = f"""<div style="font-family:Arial;padding:20px;">
            <h2 style="color:#1A2A5E;">Relatório Jardinagem — {semana_dict['label']}</h2>
            <p>Segue em anexo os relatórios fotográfico e de KM da semana.</p>
            <p style="color:#64748B;font-size:12px;">Garra Terraplenagem e Caçambas</p></div>"""
        enviar_email_smtp(MAIL_DESTINO, f"Relatório Jardinagem — {semana_dict['label']}", corpo,
                          [(nome_arquivo_semana(sem, 'Fotos'), buf_fotos.getvalue()),
                           (nome_arquivo_semana(sem, 'KM'),    buf_km.getvalue())])
        jard_query("INSERT INTO jardinagem.emails_enviados (semana_id,destinatario,assunto,status) VALUES (%s,%s,%s,'enviado')",
                   (semana_id,MAIL_DESTINO,f"Relatório {semana_dict['label']}"), fetch="none")
        jard_query("UPDATE jardinagem.semanas SET status='enviada',enviado_em=NOW() WHERE id=%s", (semana_id,), fetch="none")
        return {"ok": True, "mensagem": f"Relatórios enviados para {MAIL_DESTINO} (cc: {MAIL_CC})"}
    except Exception as e:
        jard_query("INSERT INTO jardinagem.emails_enviados (semana_id,destinatario,assunto,status,erro_msg) VALUES (%s,%s,%s,'erro',%s)",
                   (semana_id,MAIL_DESTINO,f"Relatório {semana_dict['label']}",str(e)), fetch="none")
        raise HTTPException(status_code=500, detail=f"Falha no envio: {str(e)}")

# ═══════════════════════════════════════════════════════════════════════════
# MÓDULO OPERACIONAL — Ordens de Serviço, Partes Diárias, Comissões
# Adicionado em 09/06/2026 — Fase B
# Schema: operacional.* no Neon
# ═══════════════════════════════════════════════════════════════════════════

# ── HELPERS DE QUERY (usa jard_query — mesmo padrão da jardinagem) ──────────

# ── LISTAS BÁSICAS (para popular selects) ───────────────────────────────────

@app.get("/operacional/api/tipos-servico")
async def op_listar_tipos_servico(_auth=Depends(verificar_token)):
    """Lista tipos de serviço ativos para popular select."""
    rows = jard_query(
        "SELECT id, nome, descricao, medicao FROM operacional.tipos_servico WHERE ativo=true ORDER BY nome"
    )
    return [dict(r) for r in (rows or [])]

@app.post("/operacional/api/tipos-servico")
async def op_criar_tipo_servico(request: Request, payload=Depends(verificar_admin)):
    """Cria novo tipo de serviço (somente admin/gestor)."""
    d = await request.json()
    nome = (d.get("nome") or "").strip()
    descricao = (d.get("descricao") or "").strip()
    medicao = (d.get("medicao") or "horimetro").strip().lower()
    if medicao not in ("horimetro","hora","diaria","viagem","metros","km"):
        medicao = "horimetro"
    if not nome:
        raise HTTPException(status_code=400, detail="Nome é obrigatório")
    try:
        row = jard_query(
            """INSERT INTO operacional.tipos_servico (nome, descricao, medicao, ativo)
               VALUES (%s, %s, %s, true)
               RETURNING id, nome, descricao, medicao""",
            (nome, descricao or None, medicao),
            fetch="one"
        )
        return dict(row) if row else {"nome": nome, "medicao": medicao}
    except Exception as e:
        if "duplicate" in str(e).lower():
            raise HTTPException(status_code=409, detail="Tipo de serviço já existe")
        raise HTTPException(status_code=500, detail=str(e))

@app.patch("/operacional/api/tipos-servico/{tipo_id}")
async def op_editar_tipo_servico(tipo_id: str, request: Request, payload=Depends(verificar_admin)):
    """Edita tipo de serviço (somente admin/gestor)."""
    d = await request.json()
    updates = []
    valores = []
    if "nome" in d:
        nome = (d.get("nome") or "").strip()
        if not nome:
            raise HTTPException(status_code=400, detail="Nome não pode ser vazio")
        updates.append("nome=%s"); valores.append(nome)
    if "descricao" in d:
        updates.append("descricao=%s"); valores.append((d.get("descricao") or "").strip() or None)
    if "medicao" in d:
        med = (d.get("medicao") or "horimetro").strip().lower()
        if med not in ("horimetro","hora","diaria","viagem","metros","km"):
            med = "horimetro"
        updates.append("medicao=%s"); valores.append(med)
    if not updates:
        raise HTTPException(status_code=400, detail="Nada a atualizar")
    valores.append(tipo_id)
    try:
        row = jard_query(
            f"UPDATE operacional.tipos_servico SET {', '.join(updates)} WHERE id=%s RETURNING id, nome, descricao, medicao",
            tuple(valores),
            fetch="one"
        )
        if not row:
            raise HTTPException(status_code=404, detail="Tipo de serviço não encontrado")
        return dict(row)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/operacional/api/tipos-servico/{tipo_id}")
async def op_remover_tipo_servico(tipo_id: str, payload=Depends(verificar_admin)):
    """Soft delete (ativo=false) — preserva histórico."""
    try:
        jard_query(
            "UPDATE operacional.tipos_servico SET ativo=false WHERE id=%s",
            (tipo_id,), fetch="none"
        )
        return {"ok": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── REGIMES DE COBRANÇA ──────────────────────────────────────────────────────

@app.get("/operacional/api/regimes-cobranca")
async def op_listar_regimes(_auth=Depends(verificar_token)):
    rows = jard_query(
        "SELECT id, nome, descricao FROM operacional.regimes_cobranca WHERE ativo=true ORDER BY nome"
    )
    return [dict(r) for r in (rows or [])]

@app.post("/operacional/api/regimes-cobranca")
async def op_criar_regime(request: Request, payload=Depends(verificar_gestor)):
    d = await request.json()
    nome = (d.get("nome") or "").strip().lower()
    descricao = (d.get("descricao") or "").strip()
    if not nome:
        raise HTTPException(status_code=400, detail="Nome é obrigatório")
    try:
        row = jard_query(
            """INSERT INTO operacional.regimes_cobranca (nome, descricao, ativo)
               VALUES (%s, %s, true) RETURNING id, nome, descricao""",
            (nome, descricao or None), fetch="one"
        )
        return dict(row) if row else {"nome": nome}
    except Exception as e:
        if "duplicate" in str(e).lower():
            raise HTTPException(status_code=409, detail="Regime já existe")
        raise HTTPException(status_code=500, detail=str(e))

@app.patch("/operacional/api/regimes-cobranca/{reg_id}")
async def op_editar_regime(reg_id: str, request: Request, payload=Depends(verificar_gestor)):
    d = await request.json()
    updates = []
    valores = []
    if "nome" in d:
        nome = (d.get("nome") or "").strip().lower()
        if not nome:
            raise HTTPException(status_code=400, detail="Nome não pode ser vazio")
        updates.append("nome=%s"); valores.append(nome)
    if "descricao" in d:
        updates.append("descricao=%s"); valores.append((d.get("descricao") or "").strip() or None)
    if not updates:
        raise HTTPException(status_code=400, detail="Nada a atualizar")
    valores.append(reg_id)
    try:
        row = jard_query(
            f"UPDATE operacional.regimes_cobranca SET {', '.join(updates)} WHERE id=%s RETURNING id, nome, descricao",
            tuple(valores), fetch="one"
        )
        if not row:
            raise HTTPException(status_code=404, detail="Regime não encontrado")
        return dict(row)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/operacional/api/regimes-cobranca/{reg_id}")
async def op_remover_regime(reg_id: str, payload=Depends(verificar_gestor)):
    try:
        jard_query("UPDATE operacional.regimes_cobranca SET ativo=false WHERE id=%s", (reg_id,), fetch="none")
        return {"ok": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/operacional/api/equipamentos")
async def op_listar_equipamentos(_auth=Depends(verificar_token)):
    """Lista equipamentos ativos para popular select e tela de cadastro."""
    rows = jard_query(
        """SELECT eq.id, eq.codigo, eq.descricao, eq.categoria, eq.medicao,
                  eq.marca, eq.modelo, eq.ano, eq.placa,
                  eq.horimetro_atual, eq.km_atual, eq.ativo,
                  eq.operador_responsavel_id,
                  resp.nome AS operador_responsavel_nome
           FROM operacional.equipamentos eq
           LEFT JOIN public.usuarios_garra resp ON resp.id = eq.operador_responsavel_id
           WHERE eq.ativo=true
           ORDER BY eq.categoria, eq.codigo"""
    )
    return [dict(r) for r in (rows or [])]

@app.post("/operacional/api/equipamentos")
async def op_criar_equipamento(request: Request, payload=Depends(verificar_gestor)):
    """Cria equipamento — sincroniza em operacional.equipamentos + checklist.frota."""
    d = await request.json()
    codigo    = (d.get("codigo") or "").strip()
    descricao = (d.get("descricao") or "").strip()
    categoria = (d.get("categoria") or "").strip().lower()
    medicao   = (d.get("medicao") or "horimetro").strip().lower()
    if medicao not in ("horimetro","hora","diaria","viagem","metros","km"):
        medicao = "horimetro"
    if not codigo or not descricao or not categoria:
        raise HTTPException(status_code=400, detail="Código, descrição e categoria são obrigatórios")
    marca  = (d.get("marca")  or "").strip() or None
    modelo = (d.get("modelo") or "").strip() or None
    ano    = d.get("ano")
    placa  = (d.get("placa")  or "").strip() or None
    operador_resp = (d.get("operador_responsavel_id") or "").strip() or None
    try:
        row = jard_query(
            """INSERT INTO operacional.equipamentos
               (codigo, descricao, categoria, medicao, marca, modelo, ano, placa, operador_responsavel_id, ativo)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s, true)
               RETURNING id, codigo, descricao, categoria, medicao,
                         marca, modelo, ano, placa, operador_responsavel_id""",
            (codigo, descricao, categoria, medicao, marca, modelo, ano, placa, operador_resp),
            fetch="one"
        )
        # Sincronizar com checklist.frota (mesmo código = mesma identificação)
        try:
            jard_query(
                """INSERT INTO checklist.frota (categoria, identificacao, descricao, ativo)
                   VALUES (%s, %s, %s, true)
                   ON CONFLICT (categoria, identificacao) DO UPDATE
                     SET descricao = EXCLUDED.descricao, ativo = true""",
                (categoria, codigo, descricao), fetch="none"
            )
        except Exception as sync_err:
            print(f"[Sync frota] aviso: {sync_err}")
        return dict(row) if row else {"codigo": codigo}
    except Exception as e:
        if "duplicate" in str(e).lower():
            raise HTTPException(status_code=409, detail="Código já existe")
        raise HTTPException(status_code=500, detail=str(e))

@app.patch("/operacional/api/equipamentos/{eq_id}")
async def op_editar_equipamento(eq_id: str, request: Request, payload=Depends(verificar_gestor)):
    """Edita equipamento — sincroniza com checklist.frota."""
    d = await request.json()
    updates = []
    valores = []
    for campo, key in [("codigo","codigo"),("descricao","descricao"),
                       ("categoria","categoria"),("medicao","medicao"),
                       ("marca","marca"),("modelo","modelo"),
                       ("ano","ano"),("placa","placa"),
                       ("operador_responsavel_id","operador_responsavel_id")]:
        if key in d:
            valor = d.get(key)
            if isinstance(valor, str):
                valor = valor.strip() or None
                if campo in ("categoria","medicao") and valor:
                    valor = valor.lower()
            updates.append(f"{campo}=%s"); valores.append(valor)
    if not updates:
        raise HTTPException(status_code=400, detail="Nada a atualizar")
    valores.append(eq_id)
    try:
        row = jard_query(
            f"""UPDATE operacional.equipamentos SET {', '.join(updates)}
                WHERE id=%s
                RETURNING id, codigo, descricao, categoria, medicao,
                          marca, modelo, ano, placa""",
            tuple(valores),
            fetch="one"
        )
        if not row:
            raise HTTPException(status_code=404, detail="Equipamento não encontrado")
        # Sincronizar com checklist.frota
        try:
            jard_query(
                """UPDATE checklist.frota
                     SET descricao = %s, categoria = %s, ativo = true
                   WHERE identificacao = %s""",
                (row["descricao"], row["categoria"], row["codigo"]), fetch="none"
            )
        except Exception as sync_err:
            print(f"[Sync frota] aviso: {sync_err}")
        return dict(row)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/operacional/api/equipamentos/{eq_id}")
async def op_remover_equipamento(eq_id: str, payload=Depends(verificar_gestor)):
    """Soft delete — desativa em ambas as tabelas."""
    try:
        row = jard_query(
            "UPDATE operacional.equipamentos SET ativo=false WHERE id=%s RETURNING codigo",
            (eq_id,), fetch="one"
        )
        if row and row.get("codigo"):
            try:
                jard_query(
                    "UPDATE checklist.frota SET ativo=false WHERE identificacao=%s",
                    (row["codigo"],), fetch="none"
                )
            except Exception:
                pass
        return {"ok": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/operacional/api/clientes")
async def op_listar_clientes(_auth=Depends(verificar_token)):
    """Lista clientes ativos para popular select da OS e tela de cadastro."""
    rows = jard_query(
        """SELECT id, nome, cnpj_cpf, telefone, email, contato, ativo
           FROM public.clientes_garra
           WHERE ativo=true OR ativo IS NULL
           ORDER BY nome"""
    )
    return [dict(r) for r in (rows or [])]

@app.post("/operacional/api/clientes")
async def op_criar_cliente(request: Request, payload=Depends(verificar_gestor)):
    """Cria novo cliente."""
    d = await request.json()
    nome = (d.get("nome") or "").strip()
    if not nome:
        raise HTTPException(status_code=400, detail="Nome é obrigatório")
    try:
        row = jard_query(
            """INSERT INTO public.clientes_garra
               (nome, cnpj_cpf, telefone, email, contato, ativo)
               VALUES (%s,%s,%s,%s,%s, true)
               RETURNING id, nome, cnpj_cpf, telefone, email, contato""",
            (nome,
             (d.get("cnpj_cpf") or "").strip() or None,
             (d.get("telefone") or "").strip() or None,
             (d.get("email") or "").strip() or None,
             (d.get("contato") or "").strip() or None),
            fetch="one"
        )
        return dict(row) if row else {"nome": nome}
    except Exception as e:
        if "duplicate" in str(e).lower():
            raise HTTPException(status_code=409, detail="Cliente já existe")
        raise HTTPException(status_code=500, detail=str(e))

@app.patch("/operacional/api/clientes/{cli_id}")
async def op_editar_cliente(cli_id: str, request: Request, payload=Depends(verificar_gestor)):
    """Edita cliente."""
    d = await request.json()
    updates = []
    valores = []
    for campo in ("nome","cnpj_cpf","telefone","email","contato"):
        if campo in d:
            val = d.get(campo)
            if isinstance(val, str):
                val = val.strip() or None
            updates.append(f"{campo}=%s"); valores.append(val)
    if not updates:
        raise HTTPException(status_code=400, detail="Nada a atualizar")
    valores.append(cli_id)
    try:
        row = jard_query(
            f"""UPDATE public.clientes_garra SET {', '.join(updates)}
                WHERE id=%s
                RETURNING id, nome, cnpj_cpf, telefone, email, contato""",
            tuple(valores), fetch="one"
        )
        if not row:
            raise HTTPException(status_code=404, detail="Cliente não encontrado")
        return dict(row)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/operacional/api/clientes/{cli_id}")
async def op_remover_cliente(cli_id: str, payload=Depends(verificar_gestor)):
    """Soft delete cliente."""
    try:
        jard_query(
            "UPDATE public.clientes_garra SET ativo=false WHERE id=%s",
            (cli_id,), fetch="none"
        )
        return {"ok": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/operacional/api/operadores")
async def op_listar_operadores(_auth=Depends(verificar_token)):
    """Lista usuários elegíveis a operar equipamentos (operadores, motoristas, campo)."""
    rows = jard_query(
        """SELECT id, nome, login, perfil
           FROM public.usuarios_garra
           WHERE ativo=true AND perfil IN ('operador','motorista','campo')
           ORDER BY nome"""
    )
    return [dict(r) for r in (rows or [])]


# ── NUMERAÇÃO DE OS ─────────────────────────────────────────────────────────

@app.get("/operacional/api/proximo-numero")
async def op_proximo_numero(_auth=Depends(verificar_gestor)):
    """Retorna o próximo número de OS disponível para o ano atual."""
    ano = datetime.utcnow().year
    row = jard_query(
        "SELECT operacional.proximo_numero_os(%s) AS numero",
        (ano,), fetch="one"
    )
    return {"numero": row["numero"], "ano": ano}


# ── ORDENS DE SERVIÇO ───────────────────────────────────────────────────────

@app.post("/operacional/api/os")
async def op_criar_os(request: Request, payload=Depends(verificar_gestor)):
    """Cria nova OS. Somente admin, gestor ou luana."""
    d = await request.json()

    # Campos obrigatórios
    obra = (d.get("obra") or "").strip()
    if not obra:
        raise HTTPException(status_code=400, detail="Obra é obrigatória")

    # Cliente: ou cliente_id (cadastrado) OU cliente_nome_avulso
    cliente_id = d.get("cliente_id")
    cliente_nome_avulso = (d.get("cliente_nome_avulso") or "").strip() or None
    if not cliente_id and not cliente_nome_avulso:
        raise HTTPException(status_code=400, detail="Informe cliente cadastrado ou nome avulso")

    tipo_servico_id     = d.get("tipo_servico_id")
    equipamento_id      = d.get("equipamento_id") or None
    operador_id         = d.get("operador_id") or None
    endereco            = (d.get("endereco") or "").strip() or None
    descricao           = (d.get("descricao") or "").strip() or None
    data_inicio         = d.get("data_inicio") or datetime.utcnow().date().isoformat()
    data_fim_prevista   = d.get("data_fim_prevista") or None
    codigo_erp          = (d.get("codigo_erp") or "").strip() or None
    origem              = d.get("origem") or "escritorio"

    # Gerar número de OS
    ano = datetime.utcnow().year
    row = jard_query("SELECT operacional.proximo_numero_os(%s) AS numero", (ano,), fetch="one")
    numero = row["numero"]
    sequencia = int(numero.split("-")[-1])

    # Status inicial baseado em ter ou não codigo_erp
    status = "aberta_completa" if codigo_erp else "aberta_sem_erp"

    # Snapshot do criador
    criado_por = payload.get("sub")  # login
    user_row = jard_query("SELECT id FROM public.usuarios_garra WHERE login=%s",
                         (criado_por,), fetch="one")
    criado_por_id = user_row["id"] if user_row else None

    codigo_erp_em  = datetime.utcnow() if codigo_erp else None
    codigo_erp_por = criado_por_id if codigo_erp else None

    try:
        os_row = jard_query_id(
            """INSERT INTO operacional.ordens_servico
               (numero, ano, sequencia, codigo_erp, codigo_erp_em, codigo_erp_por,
                cliente_id, cliente_nome_avulso, tipo_servico_id,
                equipamento_id, operador_id,
                obra, endereco, descricao,
                data_inicio, data_fim_prevista,
                status, origem, criado_por)
               VALUES (%s,%s,%s,%s,%s,%s, %s,%s,%s, %s,%s, %s,%s,%s, %s,%s, %s,%s,%s)""",
            (numero, ano, sequencia, codigo_erp, codigo_erp_em, codigo_erp_por,
             cliente_id, cliente_nome_avulso, tipo_servico_id,
             equipamento_id, operador_id,
             obra, endereco, descricao,
             data_inicio, data_fim_prevista,
             status, origem, criado_por_id)
        )
        return dict(os_row)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao criar OS: {str(e)}")


@app.get("/operacional/api/os")
async def op_listar_os(
    status: Optional[str] = None,
    cliente_id: Optional[str] = None,
    ano: Optional[int] = None,
    busca: Optional[str] = None,
    limit: int = 100,
    _auth=Depends(verificar_token)
):
    """Lista OS com filtros opcionais."""
    sql = """
        SELECT
            os.id, os.numero, os.ano, os.sequencia,
            os.codigo_erp, os.obra, os.endereco, os.descricao,
            os.data_inicio, os.data_fim_prevista, os.data_fim_real,
            os.status, os.origem, os.criado_em,
            os.cliente_id, COALESCE(c.nome, os.cliente_nome_avulso) AS cliente_nome,
            os.cliente_nome_avulso,
            os.tipo_servico_id, ts.nome AS tipo_servico_nome,
            os.equipamento_id, eq.codigo AS equipamento_codigo, eq.descricao AS equipamento_descricao,
            eq.medicao AS equipamento_medicao,
            eq.operador_responsavel_id AS equipamento_responsavel_id,
            resp.nome AS equipamento_responsavel_nome,
            os.operador_id, op.nome AS operador_nome,
            u.nome AS criado_por_nome
        FROM operacional.ordens_servico os
        LEFT JOIN public.clientes_garra c       ON c.id = os.cliente_id
        LEFT JOIN operacional.tipos_servico ts  ON ts.id = os.tipo_servico_id
        LEFT JOIN operacional.equipamentos eq   ON eq.id = os.equipamento_id
        LEFT JOIN public.usuarios_garra op      ON op.id = os.operador_id
        LEFT JOIN public.usuarios_garra resp    ON resp.id = eq.operador_responsavel_id
        LEFT JOIN public.usuarios_garra u       ON u.id = os.criado_por
        WHERE os.ativo = true
    """
    params = []
    if status:
        sql += " AND os.status = %s"; params.append(status)
    if cliente_id:
        sql += " AND os.cliente_id = %s"; params.append(cliente_id)
    if ano:
        sql += " AND os.ano = %s"; params.append(ano)
    if busca:
        sql += " AND (os.numero ILIKE %s OR os.obra ILIKE %s OR os.codigo_erp ILIKE %s)"
        like = f"%{busca}%"
        params.extend([like, like, like])
    sql += " ORDER BY os.ano DESC, os.sequencia DESC LIMIT %s"
    params.append(limit)

    rows = jard_query(sql, tuple(params))
    return [dict(r) for r in (rows or [])]


@app.get("/operacional/api/os/{os_id}")
async def op_detalhe_os(os_id: str, _auth=Depends(verificar_token)):
    """Retorna detalhe completo da OS, com partes diárias."""
    row = jard_query(
        """SELECT os.*,
                  COALESCE(c.nome, os.cliente_nome_avulso) AS cliente_nome,
                  ts.nome AS tipo_servico_nome,
                  u.nome AS criado_por_nome
           FROM operacional.ordens_servico os
           LEFT JOIN public.clientes_garra c       ON c.id = os.cliente_id
           LEFT JOIN operacional.tipos_servico ts  ON ts.id = os.tipo_servico_id
           LEFT JOIN operacional.equipamentos eq   ON eq.id = os.equipamento_id
           LEFT JOIN public.usuarios_garra u       ON u.id = os.criado_por
           LEFT JOIN public.usuarios_garra op      ON op.id = os.operador_id
           WHERE os.id = %s AND os.ativo = true""",
        (os_id,), fetch="one"
    )
    if not row:
        raise HTTPException(status_code=404, detail="OS não encontrada")

    # Buscar partes diárias da OS
    partes = jard_query(
        """SELECT pd.*,
                  e.codigo AS equipamento_codigo, e.descricao AS equipamento_descricao,
                  e.categoria AS equipamento_categoria,
                  COALESCE(u.nome, pd.operador_nome_avulso) AS operador_nome
           FROM operacional.partes_diarias pd
           LEFT JOIN operacional.equipamentos e  ON e.id = pd.equipamento_id
           LEFT JOIN public.usuarios_garra u    ON u.id = pd.operador_id
           WHERE pd.os_id = %s AND pd.ativo = true
           ORDER BY pd.data DESC, pd.criado_em DESC""",
        (os_id,)
    )

    os_dict = dict(row)
    os_dict["partes_diarias"] = [dict(p) for p in (partes or [])]
    return os_dict


@app.patch("/operacional/api/os/{os_id}")
async def op_atualizar_os(os_id: str, request: Request, payload=Depends(verificar_gestor)):
    """Atualiza OS — útil para inserir codigo_erp retroativo, mudar status, etc."""
    d = await request.json()

    # Verificar se OS existe
    existente = jard_query(
        "SELECT * FROM operacional.ordens_servico WHERE id=%s AND ativo=true",
        (os_id,), fetch="one"
    )
    if not existente:
        raise HTTPException(status_code=404, detail="OS não encontrada")

    # Campos editáveis
    campos_editaveis = ["codigo_erp", "obra", "endereco", "descricao",
                        "data_fim_prevista", "data_fim_real", "status",
                        "tipo_servico_id", "cliente_id", "cliente_nome_avulso",
                        "equipamento_id", "operador_id",
                        "regime_cobranca", "valor_combinado", "data_inicio"]
    updates = []
    params = []
    for campo in campos_editaveis:
        if campo in d:
            val = d[campo]
            # valor_combinado: aceitar número, vazio vira NULL
            if campo == "valor_combinado":
                val = float(val) if (val not in (None, "")) else None
            elif val == "":
                val = None
            updates.append(f"{campo} = %s")
            params.append(val)

    if not updates:
        return dict(existente)

    # Snapshot quem inseriu codigo_erp
    if "codigo_erp" in d and d["codigo_erp"]:
        login = payload.get("sub")
        user = jard_query("SELECT id FROM public.usuarios_garra WHERE login=%s",
                         (login,), fetch="one")
        if user:
            updates.append("codigo_erp_em = %s")
            params.append(datetime.utcnow())
            updates.append("codigo_erp_por = %s")
            params.append(user["id"])
        # Se tinha status aberta_sem_erp e agora tem erp, vira aberta_completa
        if existente["status"] == "aberta_sem_erp":
            updates.append("status = %s")
            params.append("aberta_completa")

    updates.append("atualizado_em = %s")
    params.append(datetime.utcnow())
    params.append(os_id)

    sql = f"UPDATE operacional.ordens_servico SET {', '.join(updates)} WHERE id = %s"
    jard_query(sql, tuple(params), fetch="none")

    # Retornar atualizado
    return await op_detalhe_os(os_id, _auth=payload)


@app.delete("/operacional/api/os/{os_id}")
async def op_remover_os(os_id: str, _auth=Depends(verificar_admin)):
    """Soft delete da OS. Somente admin."""
    jard_query(
        "UPDATE operacional.ordens_servico SET ativo=false, atualizado_em=now() WHERE id=%s",
        (os_id,), fetch="none"
    )
    return {"ok": True, "id": os_id}


# ── PARTES DIÁRIAS ──────────────────────────────────────────────────────────

@app.post("/operacional/api/os/{os_id}/partes")
async def op_criar_parte(os_id: str, request: Request, payload=Depends(verificar_token)):
    """Registra parte diária. Qualquer operador logado pode registrar numa OS ativa."""
    d = await request.json()
    login = payload.get("sub","")

    # Verificar se OS existe e está ativa
    os_row = jard_query(
        "SELECT * FROM operacional.ordens_servico WHERE id=%s AND ativo=true",
        (os_id,), fetch="one"
    )
    if not os_row:
        raise HTTPException(status_code=404, detail="OS não encontrada")

    # Campos obrigatórios
    data = d.get("data")
    vinculo = (d.get("vinculo_operador") or "proprio").lower()
    eh_terceiro = (vinculo == "terceiro")
    equipamento_terceiro = (d.get("equipamento_terceiro") or "").strip() or None
    # Terceiro: não usa equipamento da Garra; exige o nome livre
    if eh_terceiro:
        equipamento_id = None
        if not data or not equipamento_terceiro:
            raise HTTPException(status_code=400, detail="Data e equipamento de terceiro são obrigatórios")
    else:
        equipamento_id = d.get("equipamento_id") or os_row.get("equipamento_id")
        if not data or not equipamento_id:
            raise HTTPException(status_code=400, detail="Data e equipamento são obrigatórios")

    # Calcular horas trabalhadas automaticamente
    h_ini = d.get("horimetro_inicial")
    h_fin = d.get("horimetro_final")
    horas = None
    if h_ini is not None and h_fin is not None:
        try:
            horas = round(float(h_fin) - float(h_ini), 2)
            if horas < 0:
                raise HTTPException(status_code=400, detail="Horímetro final menor que inicial")
        except (TypeError, ValueError):
            pass
    # Fallback: sem horímetro, calcula horas pela hora de relógio (início→fim),
    # descontando 1h de almoço quando a jornada cruza o horário de almoço (12h)
    # e o operador NÃO marcou "dia corrido" (sem_almoco).
    # Cobre diária/viagem/empreito, onde a base de comissão vem do tempo trabalhado.
    if (horas is None or horas == 0):
        hi = d.get("hora_inicio"); hf = d.get("hora_fim")
        if hi and hf:
            try:
                ph = lambda s: int(str(s)[:2]) * 60 + int(str(s)[3:5])
                ini_m = ph(hi); fim_m = ph(hf)
                diff = fim_m - ini_m
                if diff < 0: diff += 24 * 60
                bruto = diff / 60
                cruza_almoco = (ini_m < 12*60) and (fim_m > 12*60 or fim_m < ini_m)
                sem_almoco = bool(d.get("sem_almoco"))
                almoco = 1 if (not sem_almoco and cruza_almoco and bruto > 6) else 0
                horas = round(max(0, bruto - almoco), 2)
            except (TypeError, ValueError):
                pass

    # Buscar ID do operador pelo login (quem está logado = criado_por)
    user_row = jard_query(
        "SELECT id FROM public.usuarios_garra WHERE (login=%s OR email=%s) AND ativo=true",
        (login, login), fetch="one"
    )
    criado_por_id = user_row["id"] if user_row else None

    # operador_id: pode ser informado no payload (Gilson registrando pelo Emilson)
    # ou default para quem está logado
    operador_id = d.get("operador_id") or criado_por_id

    # Calcular KM percorrido
    km_ini = d.get("km_inicial")
    km_fin = d.get("km_final")
    km_perc = None
    if km_ini is not None and km_fin is not None:
        try: km_perc = round(float(km_fin) - float(km_ini), 1)
        except: pass

    # Quantidade de metros (serviços medidos por metragem)
    qtd_metros = d.get("qtd_metros")
    try:
        qtd_metros = float(qtd_metros) if qtd_metros not in (None, "") else None
    except (TypeError, ValueError):
        qtd_metros = None

    try:
        parte = jard_query_id(
            """INSERT INTO operacional.partes_diarias
               (os_id, equipamento_id, operador_id, operador_nome_avulso,
                data, hora_inicio, hora_fim,
                tipo_medicao, horimetro_inicial, horimetro_final, horas_trabalhadas,
                km_inicial, km_final, km_percorrido,
                quantidade_diarias, qtd_viagens, qtd_metros,
                vinculo_operador, fornecedor, equipamento_terceiro, observacao, trajeto, por_conta_de, sem_almoco, criado_por)
               VALUES (%s,%s,%s,%s, %s,%s,%s, %s,%s,%s,%s, %s,%s,%s, %s,%s,%s, %s,%s,%s,%s,%s,%s,%s,%s)""",
            (os_id, equipamento_id, operador_id, d.get("operador_nome_avulso"),
             data, d.get("hora_inicio"), d.get("hora_fim"),
             d.get("tipo_medicao","horimetro"), h_ini, h_fin, horas,
             km_ini, km_fin, km_perc,
             d.get("quantidade_diarias", 0), d.get("qtd_viagens", 0), qtd_metros,
             d.get("vinculo_operador","proprio"), d.get("fornecedor"), equipamento_terceiro,
             d.get("observacao"),
             d.get("trajeto"), d.get("por_conta_de","empresa"), bool(d.get("sem_almoco")),
             criado_por_id)
        )
        # Atualizar horímetro atual do equipamento (só equipamento próprio da Garra)
        if h_fin is not None and equipamento_id:
            jard_query(
                "UPDATE operacional.equipamentos SET horimetro_atual=%s, atualizado_em=now() WHERE id=%s",
                (h_fin, equipamento_id), fetch="none"
            )
        return dict(parte)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao registrar parte: {str(e)}")


@app.get("/operacional/api/os/{os_id}/partes")
async def op_listar_partes(os_id: str, _auth=Depends(verificar_token)):
    """Lista todas as partes diárias de uma OS, com totais acumulados."""
    partes = jard_query(
        """SELECT pd.*,
                  COALESCE(e.codigo, pd.equipamento_terceiro) AS equipamento_codigo,
                  e.descricao AS equipamento_descricao,
                  e.categoria AS equipamento_categoria,
                  COALESCE(u.nome, pd.operador_nome_avulso) AS operador_nome
           FROM operacional.partes_diarias pd
           LEFT JOIN operacional.equipamentos e ON e.id = pd.equipamento_id
           LEFT JOIN public.usuarios_garra u    ON u.id = pd.operador_id
           WHERE pd.os_id = %s AND pd.ativo = true
           ORDER BY pd.data ASC, pd.criado_em ASC""",
        (os_id,)
    )
    lista = [dict(p) for p in (partes or [])]

    # Perfil do solicitante — operador/motorista NÃO vê horas cobradas (valores)
    perfil = _auth.get("perfil", "")
    eh_gestor = perfil in ("admin", "gestor", "luana", "bruna")

    if not eh_gestor:
        # Remover campos financeiros/cobrança da resposta para operador
        for p in lista:
            p.pop("horas_cobradas", None)
            p.pop("quantidade_diarias_cobradas", None)
            p.pop("valor_calculado", None)

    # Totais acumulados
    total_horas     = sum(float(p.get("horas_trabalhadas") or 0) for p in lista)
    total_diarias   = sum(float(p.get("quantidade_diarias") or 0) for p in lista)
    total_viagens   = sum(float(p.get("qtd_viagens")       or 0) for p in lista)
    dias_trabalhados= len(set(str(p.get("data",""))[:10] for p in lista if p.get("data")))

    totais = {
        "dias_trabalhados":  dias_trabalhados,
        "total_horas":       round(total_horas, 2),
        "total_diarias":     total_diarias,
        "total_viagens":     total_viagens,
    }
    # Total cobrado só para gestores
    if eh_gestor:
        total_horas_cob = sum(
            float(p.get("horas_cobradas") or 0) if float(p.get("horas_cobradas") or 0) > 0
            else float(p.get("horas_trabalhadas") or 0)
            for p in lista
        )
        totais["total_horas_cobradas"] = round(total_horas_cob, 2)

    return {"partes": lista, "totais": totais}


@app.patch("/operacional/api/partes/{parte_id}")
async def op_atualizar_parte(parte_id: str, request: Request, payload=Depends(verificar_gestor)):
    """Luana/Admin atualiza parte diária — ajusta horas cobradas, diárias, observação."""
    d = await request.json()
    existente = jard_query(
        "SELECT * FROM operacional.partes_diarias WHERE id=%s AND ativo=true",
        (parte_id,), fetch="one"
    )
    if not existente:
        raise HTTPException(status_code=404, detail="Parte diária não encontrada")
    if existente.get("fechado"):
        raise HTTPException(status_code=400, detail="Parte já fechada — não pode editar")

    campos = ["data","horas_cobradas","quantidade_diarias","quantidade_diarias_cobradas",
              "qtd_viagens","qtd_metros","observacao","hora_inicio","hora_fim",
              "horimetro_inicial","horimetro_final","km_inicial","km_final",
              "equipamento_id","operador_id","operador_nome_avulso",
              "vinculo_operador","fornecedor","por_conta_de","trajeto","sem_almoco"]
    updates, params = [], []
    for c in campos:
        if c in d:
            updates.append(f"{c} = %s")
            params.append(d[c] if d[c] != "" else None)

    # Recalcular horas se horímetro foi atualizado
    if "horimetro_inicial" in d or "horimetro_final" in d:
        h_ini = d.get("horimetro_inicial", existente.get("horimetro_inicial"))
        h_fin = d.get("horimetro_final",   existente.get("horimetro_final"))
        if h_ini is not None and h_fin is not None:
            horas = round(float(h_fin) - float(h_ini), 2)
            updates.append("horas_trabalhadas = %s")
            params.append(horas)

    # Recalcular km_percorrido se km foi atualizado
    if "km_inicial" in d or "km_final" in d:
        k_ini = d.get("km_inicial", existente.get("km_inicial"))
        k_fin = d.get("km_final",   existente.get("km_final"))
        if k_ini is not None and k_fin is not None:
            updates.append("km_percorrido = %s")
            params.append(round(float(k_fin) - float(k_ini), 1))

    if not updates:
        return dict(existente)

    params.append(parte_id)
    jard_query(
        f"UPDATE operacional.partes_diarias SET {', '.join(updates)} WHERE id=%s",
        tuple(params), fetch="none"
    )
    row = jard_query(
        "SELECT * FROM operacional.partes_diarias WHERE id=%s", (parte_id,), fetch="one"
    )
    return dict(row)


@app.delete("/operacional/api/partes/{parte_id}")
async def op_remover_parte(parte_id: str, _auth=Depends(verificar_gestor)):
    """Soft delete de parte diária."""
    existente = jard_query(
        "SELECT fechado FROM operacional.partes_diarias WHERE id=%s AND ativo=true",
        (parte_id,), fetch="one"
    )
    if not existente:
        raise HTTPException(status_code=404, detail="Parte não encontrada")
    if existente.get("fechado"):
        raise HTTPException(status_code=400, detail="Parte fechada — não pode remover")
    jard_query(
        "UPDATE operacional.partes_diarias SET ativo=false WHERE id=%s",
        (parte_id,), fetch="none"
    )
    return {"ok": True, "id": parte_id}


@app.post("/operacional/api/os/{os_id}/fechar")
async def op_fechar_os(os_id: str, request: Request, payload=Depends(verificar_gestor)):
    """Fecha OS após revisão pela Luana. Congela todas as partes diárias."""
    os_row = jard_query(
        "SELECT * FROM operacional.ordens_servico WHERE id=%s AND ativo=true",
        (os_id,), fetch="one"
    )
    if not os_row:
        raise HTTPException(status_code=404, detail="OS não encontrada")
    if os_row.get("status") in ("concluida_completa","concluida_sem_erp","cancelada"):
        raise HTTPException(status_code=400, detail="OS já está fechada")

    login = payload.get("sub","")
    user  = jard_query(
        "SELECT id FROM public.usuarios_garra WHERE login=%s", (login,), fetch="one"
    )
    fechado_por_id = user["id"] if user else None
    agora = datetime.utcnow()

    # Auto-preencher horas_cobradas = horas_trabalhadas onde não foi editado (cobradas=0 ou null)
    jard_query(
        """UPDATE operacional.partes_diarias
           SET horas_cobradas = horas_trabalhadas
           WHERE os_id=%s AND ativo=true AND fechado=false
             AND (horas_cobradas IS NULL OR horas_cobradas = 0)
             AND horas_trabalhadas > 0""",
        (os_id,), fetch="none"
    )

    # Fechar todas as partes abertas
    jard_query(
        """UPDATE operacional.partes_diarias
           SET fechado=true, fechado_em=%s, fechado_por=%s
           WHERE os_id=%s AND ativo=true AND fechado=false""",
        (agora, fechado_por_id, os_id), fetch="none"
    )

    # Determinar status final
    novo_status = "concluida_completa" if os_row.get("codigo_erp") else "concluida_sem_erp"

    jard_query(
        """UPDATE operacional.ordens_servico
           SET status=%s, data_fim_real=%s, atualizado_em=%s
           WHERE id=%s""",
        (novo_status, agora.date(), agora, os_id), fetch="none"
    )

    return await op_detalhe_os(os_id, _auth=payload)


@app.post("/operacional/api/os/{os_id}/concluir")
async def op_concluir_os_operador(os_id: str, request: Request, payload=Depends(verificar_token)):
    """Operador marca OS como concluída do lado dele → aguarda fechamento pela Luana."""
    login = payload.get("sub","") or payload.get("login","")
    user = jard_query(
        "SELECT id, perfil FROM public.usuarios_garra WHERE login=%s",
        (login,), fetch="one"
    )
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    os_row = jard_query(
        "SELECT id, numero, status, operador_id FROM operacional.ordens_servico WHERE id=%s AND ativo=true",
        (os_id,), fetch="one"
    )
    if not os_row:
        raise HTTPException(status_code=404, detail="OS não encontrada")

    # Verificar se o operador é dono da OS ou admin/gestor
    if user["perfil"] not in ("admin","gestor","luana") and str(os_row.get("operador_id")) != str(user["id"]):
        raise HTTPException(status_code=403, detail="Você não é o operador desta OS")

    if os_row.get("status") in ("concluida_completa","concluida_sem_erp","cancelada","aguardando_fechamento"):
        raise HTTPException(status_code=400, detail="OS já está concluída ou aguardando fechamento")

    agora = datetime.utcnow()
    jard_query(
        """UPDATE operacional.ordens_servico
           SET status='aguardando_fechamento', atualizado_em=%s
           WHERE id=%s""",
        (agora, os_id), fetch="none"
    )

    return {"ok": True, "numero": os_row.get("numero"), "status": "aguardando_fechamento"}


@app.post("/operacional/api/os/{os_id}/liberar")
async def op_liberar_os(os_id: str, payload=Depends(verificar_token)):
    """
    Operador LIBERA a OS (foi movido para outra obra/máquina).
    A OS perde o responsável (operador_id = NULL) → vira órfã → cai no alerta
    vermelho do admin para a Luana redesignar.
    As partes já registradas continuam com o operador original (comissão preservada).
    """
    login = payload.get("sub","") or payload.get("login","")
    user = jard_query(
        "SELECT id, perfil FROM public.usuarios_garra WHERE login=%s",
        (login,), fetch="one"
    )
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    os_row = jard_query(
        "SELECT id, numero, status, operador_id FROM operacional.ordens_servico WHERE id=%s AND ativo=true",
        (os_id,), fetch="one"
    )
    if not os_row:
        raise HTTPException(status_code=404, detail="OS não encontrada")

    # Só o operador dono (ou admin/gestor) pode liberar
    if user["perfil"] not in ("admin","gestor","luana") and str(os_row.get("operador_id")) != str(user["id"]):
        raise HTTPException(status_code=403, detail="Você não é o operador desta OS")

    if os_row.get("status") in ("concluida_completa","concluida_sem_erp","cancelada"):
        raise HTTPException(status_code=400, detail="OS já está concluída")

    # Zera o responsável → OS órfã. Partes diárias NÃO são tocadas (mantêm operador_id).
    agora = datetime.utcnow()
    jard_query(
        """UPDATE operacional.ordens_servico
           SET operador_id=NULL, atualizado_em=%s
           WHERE id=%s""",
        (agora, os_id), fetch="none"
    )

    return {"ok": True, "numero": os_row.get("numero"), "liberada": True}


@app.get("/operacional/api/os/{os_id}/revisao")
async def op_revisao_os(os_id: str, _auth=Depends(verificar_gestor)):
    """Tela de revisão antes de fechar: OS + partes + totais consolidados."""
    os_detail = await op_detalhe_os(os_id, _auth=_auth)
    partes_data = await op_listar_partes(os_id, _auth=_auth)
    return {
        "os":     os_detail,
        "partes": partes_data["partes"],
        "totais": partes_data["totais"],
    }


@app.get("/operacional/api/minhas-partes")
async def op_minhas_partes(payload=Depends(verificar_token)):
    """Operador vê histórico de partes diárias próprias."""
    login = payload.get("sub","")
    user = jard_query(
        "SELECT id FROM public.usuarios_garra WHERE login=%s", (login,), fetch="one"
    )
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    rows = jard_query(
        """SELECT pd.*, os.numero AS numero_os, os.obra,
                  e.codigo AS equipamento_codigo
           FROM operacional.partes_diarias pd
           JOIN operacional.ordens_servico os ON os.id = pd.os_id
           LEFT JOIN operacional.equipamentos e ON e.id = pd.equipamento_id
           WHERE pd.operador_id = %s AND pd.ativo = true
           ORDER BY pd.data DESC, pd.criado_em DESC
           LIMIT 60""",
        (user["id"],)
    )
    return [dict(r) for r in (rows or [])]


@app.get("/operacional/api/minhas-os")
async def op_minhas_os(historico: int = 0, payload=Depends(verificar_token)):
    """Operador/motorista vê suas OS. historico=0: ativas | historico=1: concluídas."""
    login = payload.get("sub","")
    user  = jard_query(
        "SELECT id, perfil FROM public.usuarios_garra WHERE login=%s", (login,), fetch="one"
    )
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    # Verificar permissão do módulo operacional_mobile
    perm = jard_query(
        "SELECT permitido FROM public.permissoes_colaborador WHERE usuario_id=%s AND modulo='operacional_mobile'",
        (user["id"],), fetch="one"
    )
    if perm and perm.get("permitido") == False:
        # Permissão explicitamente negada → retorna lista vazia
        return []
    # Se não tem registro, usa padrão do perfil (operador/motorista/admin/gestor/luana/bruna têm acesso)
    if not perm:
        perfis_com_acesso = ('admin','gestor','luana','bruna','operador','motorista')
        if user.get("perfil") not in perfis_com_acesso:
            return []

    # Filtro de status conforme histórico ou ativas
    if historico == 1:
        status_filter = "os.status IN ('concluida_completa','concluida_sem_erp','aguardando_fechamento')"
    else:
        status_filter = "os.status NOT IN ('concluida_completa','concluida_sem_erp','cancelada')"

    rows = jard_query(
        f"""SELECT os.id, os.numero, os.obra, os.regime_cobranca,
                  os.data_inicio, os.data_fim_prevista, os.status,
                  os.equipamento_id, os.operador_id, os.tipo_servico_id, os.cliente_id,
                  COALESCE(c.nome, os.cliente_nome_avulso) AS cliente_nome,
                  e.codigo AS equipamento_codigo, e.descricao AS equipamento_descricao,
                  e.medicao AS equipamento_medicao,
                  ts.nome AS tipo_servico_nome, ts.medicao AS tipo_servico_medicao
           FROM operacional.ordens_servico os
           LEFT JOIN public.clientes_garra c      ON c.id = os.cliente_id
           LEFT JOIN operacional.equipamentos e   ON e.id = os.equipamento_id
           LEFT JOIN operacional.tipos_servico ts ON ts.id = os.tipo_servico_id
           WHERE os.operador_id = %s
             AND os.ativo = true
             AND {status_filter}
           ORDER BY os.data_inicio DESC""",
        (user["id"],)
    )
    # Sem campos financeiros — operador não vê valores
    return [dict(r) for r in (rows or [])]


@app.get("/operacional/api/minhas-os/debug")
async def op_minhas_os_debug(payload=Depends(verificar_token)):
    """DEBUG — mostra todos os campos para diagnosticar por que OS não aparece."""
    login = payload.get("sub","") or payload.get("login","")
    user = jard_query(
        "SELECT id, login, nome, perfil FROM public.usuarios_garra WHERE login=%s",
        (login,), fetch="one"
    )
    if not user:
        return {"erro": "usuário não encontrado", "login_buscado": login}
    
    todas_os = jard_query(
        """SELECT id, numero, status, ativo, operador_id, obra
           FROM operacional.ordens_servico
           WHERE operador_id = %s
           ORDER BY data_inicio DESC""",
        (user["id"],)
    )
    
    os_visiveis = jard_query(
        """SELECT id, numero, status
           FROM operacional.ordens_servico
           WHERE operador_id = %s
             AND ativo = true
             AND status NOT IN ('concluida_completa','concluida_sem_erp','cancelada')""",
        (user["id"],)
    )
    
    return {
        "login_jwt": login,
        "usuario": dict(user),
        "total_os_vinculadas": len(todas_os or []),
        "todas_os": [dict(r) for r in (todas_os or [])],
        "os_visiveis_no_mobile": [dict(r) for r in (os_visiveis or [])]
    }


@app.post("/operacional/api/os/avulsa")
async def op_criar_os_avulsa(req: Request, payload=Depends(verificar_token)):
    """Operador cria OS avulsa do campo — sem código ERP, status aberta_sem_erp."""
    login = payload.get("sub","") or payload.get("login","")
    user = jard_query(
        "SELECT id, nome, perfil FROM public.usuarios_garra WHERE login=%s",
        (login,), fetch="one"
    )
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    
    # Perfis autorizados
    if user["perfil"] not in ("operador", "motorista", "admin", "gestor", "luana"):
        raise HTTPException(status_code=403, detail="Perfil sem permissão para criar OS avulsa")
    
    body = await req.json()
    obra            = (body.get("obra") or "").strip()
    cliente_nome    = (body.get("cliente_nome") or "").strip()
    equipamento_id  = body.get("equipamento_id")
    tipo_servico_id = body.get("tipo_servico_id")
    regime_cobranca = (body.get("regime_cobranca") or "diaria").strip()
    observacao      = (body.get("observacao") or "").strip()
    
    if not obra:
        raise HTTPException(status_code=400, detail="Obra é obrigatória")
    
    # Gerar próximo número
    ano = datetime.utcnow().year
    ult = jard_query(
        "SELECT numero, sequencia FROM operacional.ordens_servico WHERE numero LIKE %s ORDER BY sequencia DESC LIMIT 1",
        (f"OS-{ano}-%",), fetch="one"
    )
    if ult and ult.get("sequencia"):
        seq = int(ult["sequencia"]) + 1
    elif ult:
        try:
            seq = int(ult["numero"].split("-")[-1]) + 1
        except Exception:
            seq = 1
    else:
        seq = 1
    numero = f"OS-{ano}-{seq:04d}"
    
    nova = jard_query(
        """INSERT INTO operacional.ordens_servico
           (numero, ano, sequencia, obra, cliente_nome_avulso,
            equipamento_id, tipo_servico_id, regime_cobranca,
            operador_id, status, origem, descricao,
            data_inicio, ativo, criado_por, criado_em)
           VALUES (%s, %s, %s, %s, %s,
                   %s, %s, %s,
                   %s, 'aberta_sem_erp', 'campo', %s,
                   CURRENT_DATE, true, %s, NOW())
           RETURNING id, numero, obra, status""",
        (numero, ano, seq, obra, cliente_nome or None,
         equipamento_id, tipo_servico_id, regime_cobranca,
         user["id"], observacao or None, user["id"]),
        fetch="one"
    )
    return {"ok": True, "os": dict(nova) if nova else {"numero": numero}}

# ── CONTROLE MENSAL ───────────────────────────────────────────────────────────

@app.get("/operacional/api/controle-mensal/periodos")
async def op_controle_mensal_periodos(db=Depends(get_db), _auth=Depends(verificar_gestor)):
    """Lista os meses que têm partes diárias salvas, agrupados por ano.
    Alimenta o menu suspenso de períodos do Controle Mensal (asyncpg — regra #44)."""
    rows = await db.fetch("""
        SELECT EXTRACT(YEAR FROM data)::int  AS ano,
               EXTRACT(MONTH FROM data)::int AS mes,
               COUNT(*)::int                 AS total
        FROM operacional.partes_diarias
        WHERE ativo = TRUE
        GROUP BY 1, 2
        ORDER BY 1 DESC, 2 DESC
    """)
    return [dict(r) for r in rows]


@app.get("/operacional/api/controle-mensal")
async def op_controle_mensal(
    ano: int,
    mes: int = None,
    equipamento_id: str = None,
    operador_id: str = None,
    _auth=Depends(verificar_gestor)
):
    """Retorna partes diárias do mês (ou do ANO inteiro, se mes ausente)
    para preview do controle mensal / exportação anual."""
    filtros = ["pd.ativo=true"]
    params = []
    if mes:
        filtros.append("EXTRACT(MONTH FROM pd.data)=%s")
        params.append(mes)
    filtros.append("EXTRACT(YEAR FROM pd.data)=%s")
    params.append(ano)

    if equipamento_id:
        filtros.append("pd.equipamento_id=%s")
        params.append(equipamento_id)
    if operador_id:
        filtros.append("pd.operador_id=%s")
        params.append(operador_id)

    where = " AND ".join(filtros)

    rows = jard_query(f"""
        SELECT pd.id, pd.data, pd.tipo_medicao,
               pd.horimetro_inicial, pd.horimetro_final, pd.horas_trabalhadas, pd.horas_cobradas,
               pd.km_inicial, pd.km_final, pd.km_percorrido,
               pd.qtd_metros, pd.qtd_viagens,
               pd.hora_inicio, pd.hora_fim, pd.sem_almoco,
               pd.por_conta_de, pd.observacao, pd.fechado,
               pd.equipamento_id, pd.operador_id, pd.os_id,
               pd.equipamento_terceiro, pd.vinculo_operador, pd.fornecedor,
               COALESCE(e.codigo, pd.equipamento_terceiro) AS equipamento_codigo,
               e.descricao AS equipamento_descricao,
               e.categoria AS equipamento_categoria, e.medicao AS equipamento_medicao,
               u.nome AS operador_nome,
               os.numero AS os_numero, os.obra AS os_obra, os.regime_cobranca,
               os.codigo_erp,
               COALESCE(c.nome, os.cliente_nome_avulso) AS cliente_nome
        FROM operacional.partes_diarias pd
        LEFT JOIN operacional.equipamentos e ON e.id = pd.equipamento_id
        LEFT JOIN public.usuarios_garra u    ON u.id = pd.operador_id
        LEFT JOIN operacional.ordens_servico os ON os.id = pd.os_id
        LEFT JOIN public.clientes_garra c    ON c.id = os.cliente_id
        WHERE {where}
        ORDER BY pd.data, e.codigo, u.nome
    """, tuple(params))

    # Listar equipamentos e operadores do mês (para filtros)
    equipamentos = {}
    operadores = {}
    partes = []
    total_horas_trab = 0
    total_horas_cobr = 0
    total_km = 0
    total_metros = 0
    total_viagens = 0
    dias_trabalhados = set()

    for r in (rows or []):
        d = dict(r)
        # Converter date para string ISO
        if d.get("data"):
            d["data"] = str(d["data"])
        if d.get("hora_inicio"):
            d["hora_inicio"] = str(d["hora_inicio"])
        if d.get("hora_fim"):
            d["hora_fim"] = str(d["hora_fim"])

        # Horas trabalhadas: usa o gravado; se vazio, calcula pelo relógio
        # com desconto de almoço (cobre registros antigos sem horas_trabalhadas)
        horas_trab = float(d.get("horas_trabalhadas") or 0)
        if horas_trab <= 0 and d.get("hora_inicio") and d.get("hora_fim"):
            try:
                ph = lambda s: int(str(s)[:2]) * 60 + int(str(s)[3:5])
                im = ph(d["hora_inicio"]); fm = ph(d["hora_fim"])
                dm = fm - im
                if dm < 0: dm += 24 * 60
                bruto = dm / 60
                cruza = (im < 12*60) and (fm > 12*60 or fm < im)
                almoco = 1 if (not d.get("sem_almoco") and cruza and bruto > 6) else 0
                horas_trab = round(max(0, bruto - almoco), 2)
                d["horas_trabalhadas"] = horas_trab
            except (TypeError, ValueError):
                pass

        partes.append(d)
        dias_trabalhados.add(d["data"])
        total_horas_trab += horas_trab
        total_horas_cobr += float(d.get("horas_cobradas") or 0)
        total_km += float(d.get("km_percorrido") or 0)
        total_metros += float(d.get("qtd_metros") or 0)
        total_viagens += float(d.get("qtd_viagens") or 0)

        if d.get("equipamento_id") and d.get("equipamento_codigo"):
            equipamentos[d["equipamento_id"]] = {
                "id": d["equipamento_id"],
                "codigo": d["equipamento_codigo"],
                "descricao": d["equipamento_descricao"]
            }
        if d.get("operador_id") and d.get("operador_nome"):
            operadores[d["operador_id"]] = {
                "id": d["operador_id"],
                "nome": d["operador_nome"]
            }

    import calendar
    if mes:
        dias_no_mes = calendar.monthrange(ano, mes)[1]
    else:
        dias_no_mes = 366 if calendar.isleap(ano) else 365

    return {
        "mes": mes, "ano": ano,
        "dias_no_mes": dias_no_mes,
        "total_registros": len(partes),
        "dias_trabalhados": len(dias_trabalhados),
        "dias_parados": dias_no_mes - len(dias_trabalhados),
        "total_horas_trabalhadas": round(total_horas_trab, 2),
        "total_horas_cobradas": round(total_horas_cobr, 2),
        "total_km": round(total_km, 2),
        "total_metros": round(total_metros, 2),
        "total_viagens": int(total_viagens),
        "equipamentos": list(equipamentos.values()),
        "operadores": list(operadores.values()),
        "partes": partes
    }


@app.get("/operacional/api/controle-mensal/excel")
async def op_controle_mensal_excel(
    ano: int,
    mes: int = None,
    view: str = "equipamento",
    equipamento_id: str = None,
    operador_id: str = None,
    _auth=Depends(verificar_gestor)
):
    """Gera Excel do controle mensal (ou ANUAL, se mes ausente) —
    1 aba por equipamento ou por colaborador."""
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter
    import io, calendar

    # Buscar dados
    dados = await op_controle_mensal(ano=ano, mes=mes, equipamento_id=equipamento_id, operador_id=operador_id, _auth=_auth)
    partes = dados["partes"]

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    meses_pt = ['','Janeiro','Fevereiro','Março','Abril','Maio','Junho',
                'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro']
    if mes:
        titulo_mes = f"{meses_pt[mes]}/{ano}"
        titulo_doc = f"CONTROLE MENSAL — {titulo_mes}"
    else:
        titulo_mes = f"Ano {ano}"
        titulo_doc = f"CONTROLE ANUAL — {ano}"

    header_font = Font(bold=True, size=10, color="FFFFFF")
    header_fill = PatternFill(start_color="1A2A5E", end_color="1A2A5E", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell_align = Alignment(vertical="center")
    border = Border(
        left=Side(style='thin', color='CBD5E1'),
        right=Side(style='thin', color='CBD5E1'),
        top=Side(style='thin', color='CBD5E1'),
        bottom=Side(style='thin', color='CBD5E1')
    )
    total_fill = PatternFill(start_color="FFF7ED", end_color="FFF7ED", fill_type="solid")
    total_font = Font(bold=True, size=10)

    if view == "equipamento":
        # Agrupar por equipamento
        grupos = {}
        for p in partes:
            key = p.get("equipamento_id") or "sem_equipamento"
            label = f"{p.get('equipamento_codigo','?')} — {p.get('equipamento_descricao','')}"
            if key not in grupos:
                grupos[key] = {"label": label, "partes": []}
            grupos[key]["partes"].append(p)
    else:
        # Agrupar por operador
        grupos = {}
        for p in partes:
            key = p.get("operador_id") or "sem_operador"
            label = p.get("operador_nome") or "Sem operador"
            if key not in grupos:
                grupos[key] = {"label": label, "partes": []}
            grupos[key]["partes"].append(p)

    if not grupos:
        # Aba vazia
        ws = wb.create_sheet("Sem dados")
        ws["A1"] = f"Nenhum registro encontrado para {titulo_mes}"
    else:
        for key, grupo in grupos.items():
            nome_aba = grupo["label"][:31]  # Excel limita 31 chars
            ws = wb.create_sheet(nome_aba)

            # Título
            ws.merge_cells('A1:K1')
            ws['A1'] = titulo_doc
            ws['A1'].font = Font(bold=True, size=14, color="1A2A5E")
            ws.merge_cells('A2:K2')
            ws['A2'] = grupo["label"]
            ws['A2'].font = Font(bold=True, size=11, color="E8820C")

            # Headers
            headers = ['Data','Cód Interno','OS','Cliente','Operador' if view=='equipamento' else 'Equipamento',
                       'H.Inicial','H.Final','Horas Trab.','Horas Cobr.','Regime','Por conta']
            for col, h in enumerate(headers, 1):
                cell = ws.cell(row=4, column=col, value=h)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = header_align
                cell.border = border

            row = 5
            soma_trab = 0
            soma_cobr = 0
            dias_set = set()

            for p in sorted(grupo["partes"], key=lambda x: x.get("data","")):
                data_fmt = ""
                if p.get("data"):
                    try:
                        from datetime import date as dt_date
                        d = dt_date.fromisoformat(p["data"])
                        data_fmt = d.strftime("%d/%m/%Y")
                    except Exception:
                        data_fmt = p["data"]

                med = p.get("tipo_medicao") or p.get("equipamento_medicao") or "horimetro"
                if med == "metros":
                    h_ini = ""
                    h_fin = ""
                    h_trab = float(p.get("qtd_metros") or 0)
                    h_cobr = float(p.get("qtd_metros") or 0)
                elif med == "km":
                    h_ini = float(p.get("km_inicial") or 0)
                    h_fin = float(p.get("km_final") or 0)
                    h_trab = float(p.get("km_percorrido") or 0)
                    h_cobr = float(p.get("km_percorrido") or 0)
                else:
                    h_ini = float(p.get("horimetro_inicial") or 0)
                    h_fin = float(p.get("horimetro_final") or 0)
                    h_trab = float(p.get("horas_trabalhadas") or 0)
                    h_cobr = float(p.get("horas_cobradas") or h_trab)

                soma_trab += h_trab
                soma_cobr += h_cobr
                dias_set.add(p.get("data"))

                col4 = p.get("operador_nome","") if view == "equipamento" else p.get("equipamento_codigo","")
                valores = [
                    data_fmt,
                    p.get("os_numero",""),
                    p.get("codigo_erp","") or "",
                    p.get("cliente_nome",""),
                    col4,
                    h_ini, h_fin,
                    round(h_trab, 2) if h_trab else 0,
                    round(h_cobr, 2) if h_cobr else 0,
                    p.get("regime_cobranca",""),
                    p.get("por_conta_de","")
                ]
                for col, v in enumerate(valores, 1):
                    cell = ws.cell(row=row, column=col, value=v)
                    cell.alignment = cell_align
                    cell.border = border
                row += 1

            # Linha TOTAL
            row += 1
            ws.cell(row=row, column=1, value="TOTAL").font = total_font
            ws.cell(row=row, column=1).fill = total_fill
            ws.cell(row=row, column=8, value=round(soma_trab, 2)).font = total_font
            ws.cell(row=row, column=8).fill = total_fill
            ws.cell(row=row, column=9, value=round(soma_cobr, 2)).font = total_font
            ws.cell(row=row, column=9).fill = total_fill

            ws.cell(row=row+1, column=1, value=f"Dias trabalhados: {len(dias_set)}").font = Font(size=10, color="64748B")
            dias_no_mes = dados["dias_no_mes"]
            ws.cell(row=row+2, column=1, value=f"Dias parados: {dias_no_mes - len(dias_set)}").font = Font(size=10, color="64748B")

            # Larguras (11 colunas: Data, Cód Interno, OS, Cliente, Op/Equip, H.Ini, H.Fin, Trab, Cobr, Regime, Conta)
            widths = [12, 14, 14, 22, 16, 10, 10, 12, 12, 10, 12]
            for i, w in enumerate(widths, 1):
                ws.column_dimensions[get_column_letter(i)].width = w

    # Aba RESUMO
    ws_res = wb.create_sheet("RESUMO", 0)
    ws_res['A1'] = titulo_doc
    ws_res['A1'].font = Font(bold=True, size=14, color="1A2A5E")
    ws_res['A3'] = "Total de registros:"
    ws_res['B3'] = dados["total_registros"]
    ws_res['A4'] = "Dias trabalhados:"
    ws_res['B4'] = dados["dias_trabalhados"]
    ws_res['A5'] = "Dias parados:"
    ws_res['B5'] = dados["dias_parados"]
    ws_res['A6'] = "Horas trabalhadas:"
    ws_res['B6'] = dados["total_horas_trabalhadas"]
    ws_res['A7'] = "Horas cobradas:"
    ws_res['B7'] = dados["total_horas_cobradas"]
    ws_res['A8'] = "KM total:"
    ws_res['B8'] = dados["total_km"]
    ws_res['A9'] = "Metros total:"
    ws_res['B9'] = dados["total_metros"]
    for r in range(3,10):
        ws_res.cell(row=r, column=1).font = Font(bold=True, size=10)
    ws_res.column_dimensions['A'].width = 22
    ws_res.column_dimensions['B'].width = 15

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    view_label = "equipamento" if view == "equipamento" else "colaborador"
    if mes:
        filename = f"controle-mensal-{view_label}-{meses_pt[mes].lower()}{ano}.xlsx"
    else:
        filename = f"controle-anual-{view_label}-{ano}.xlsx"

    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )


# ═══════════════════════════════════════════════════════════════════════════
# FIM MÓDULO OPERACIONAL
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
# MÓDULO PERMISSÕES — controle por colaborador
# ═══════════════════════════════════════════════════════════════════════════
# PERFIS CUSTOMIZADOS (persistência real — antes só existia em memória JS)
# ═══════════════════════════════════════════════════════════════════════════


@app.on_event("startup")
async def criar_tabela_perfis():
    try:
        jard_query(PERFIS_TABLE_SQL, fetch="none")
        existe = jard_query("SELECT COUNT(*) as c FROM public.perfis_customizados", fetch="one")
        if existe and existe.get("c", 0) == 0:
            for nome, modulos in PERFIL_MODULOS_PADRAO.items():
                label = PERFIL_LABEL_SEED.get(nome, nome.capitalize())
                jard_query(
                    "INSERT INTO public.perfis_customizados (nome, label, modulos) VALUES (%s, %s, %s)",
                    (nome, label, ",".join(modulos)), fetch="none"
                )
    except Exception:
        pass


@app.get("/permissoes/perfis")
async def listar_perfis(payload=Depends(verificar_admin)):
    """Lista todos os perfis persistidos (usado para hidratar a tela Permissões)."""
    rows = jard_query(
        "SELECT nome, label, modulos FROM public.perfis_customizados WHERE ativo=true ORDER BY nome",
        fetch="all"
    ) or []
    return [
        {
            "nome": r["nome"],
            "label": r["label"],
            "modulos": [m.strip() for m in (r.get("modulos") or "").split(",") if m.strip()],
        }
        for r in rows
    ]

class PerfilCreate(BaseModel):
    nome: str
    label: str
    modulos: List[str] = []

@app.post("/permissoes/perfis")
async def criar_perfil(dados: PerfilCreate, payload=Depends(verificar_admin)):
    """Cria um novo perfil, persistido no banco."""
    nome = dados.nome.strip().lower().replace(" ", "_")
    if not nome:
        raise HTTPException(status_code=400, detail="Nome é obrigatório")
    existe = jard_query("SELECT nome FROM public.perfis_customizados WHERE nome=%s", (nome,), fetch="one")
    if existe:
        raise HTTPException(status_code=409, detail="Perfil já existe")
    jard_query(
        "INSERT INTO public.perfis_customizados (nome, label, modulos) VALUES (%s, %s, %s)",
        (nome, dados.label, ",".join(dados.modulos)), fetch="none"
    )
    return {"ok": True, "nome": nome}

class PerfilUpdate(BaseModel):
    modulos: List[str]
    label: Optional[str] = None

@app.put("/permissoes/perfis/{nome}")
async def atualizar_perfil(nome: str, dados: PerfilUpdate, payload=Depends(verificar_admin)):
    """Atualiza os módulos padrão (e opcionalmente o label) de um perfil existente."""
    modulos_str = ",".join(dados.modulos)
    if dados.label:
        jard_query(
            "UPDATE public.perfis_customizados SET modulos=%s, label=%s, atualizado_em=NOW() WHERE nome=%s",
            (modulos_str, dados.label, nome), fetch="none"
        )
    else:
        jard_query(
            "UPDATE public.perfis_customizados SET modulos=%s, atualizado_em=NOW() WHERE nome=%s",
            (modulos_str, nome), fetch="none"
        )
    return {"ok": True}

@app.delete("/permissoes/perfis/{nome}")
async def excluir_perfil_db(nome: str, payload=Depends(verificar_admin)):
    """Remove um perfil — bloqueado se houver colaboradores ativos usando ele."""
    if nome == "admin":
        raise HTTPException(status_code=400, detail="Perfil Admin não pode ser removido")
    count = jard_query(
        "SELECT COUNT(*) as c FROM public.usuarios_garra WHERE perfil=%s AND ativo=true",
        (nome,), fetch="one"
    )
    if count and count.get("c", 0) > 0:
        raise HTTPException(status_code=400, detail=f"Impossível — {count['c']} colaborador(es) com este perfil")
    jard_query("DELETE FROM public.perfis_customizados WHERE nome=%s", (nome,), fetch="none")
    return {"ok": True}

# FIM PERFIS CUSTOMIZADOS
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/permissoes/modulos")
async def listar_modulos(_auth=Depends(verificar_admin)):
    """Lista módulos disponíveis."""
    return MODULOS_DISPONIVEIS

@app.get("/permissoes/usuario/{usuario_id}")
async def get_permissoes_usuario(usuario_id: str, payload=Depends(verificar_token)):
    """Retorna permissões. Admin vê qualquer usuário; usuário vê só as próprias."""
    sub = payload.get("sub","")
    perfil = payload.get("perfil","")
    # Buscar UUID do usuário logado se sub for login
    if perfil != "admin":
        user = jard_query(
            "SELECT id FROM public.usuarios_garra WHERE (login=%s OR email=%s) AND ativo=true",
            (sub, sub), fetch="one"
        )
        uid_logado = str(user["id"]) if user else None
        if uid_logado != usuario_id:
            raise HTTPException(status_code=403, detail="Acesso negado")
    rows = jard_query(
        "SELECT modulo, permitido FROM public.permissoes_colaborador WHERE usuario_id=%s",
        (usuario_id,)
    )
    perms = {r["modulo"]: r["permitido"] for r in (rows or [])}
    # Se não tem registro, usa padrão do perfil
    user = jard_query(
        "SELECT perfil FROM public.usuarios_garra WHERE id=%s AND ativo=true",
        (usuario_id,), fetch="one"
    )
    if user:
        padrao = perfil_modulos_padrao(user["perfil"])
        for m in MODULOS_DISPONIVEIS:
            if m["id"] not in perms:
                perms[m["id"]] = m["id"] in padrao
    return perms

@app.post("/permissoes/usuario/{usuario_id}")
async def salvar_permissoes_usuario(usuario_id: str, request: Request, _auth=Depends(verificar_admin)):
    """Salva permissões de um colaborador. Body: {modulo: bool, ...}"""
    d = await request.json()
    for modulo, permitido in d.items():
        jard_query(
            """INSERT INTO public.permissoes_colaborador (usuario_id, modulo, permitido)
               VALUES (%s, %s, %s)
               ON CONFLICT (usuario_id, modulo)
               DO UPDATE SET permitido=%s, atualizado_em=now()""",
            (usuario_id, modulo, bool(permitido), bool(permitido)), fetch="none"
        )
    return {"ok": True}

@app.get("/permissoes/todos")
async def get_todas_permissoes(_auth=Depends(verificar_admin)):
    """Retorna permissões de todos os usuários ativos para a tela de gestão."""
    usuarios = jard_query(
        "SELECT id, login, nome, perfil FROM public.usuarios_garra WHERE ativo=true ORDER BY perfil, nome"
    )
    perms = jard_query(
        "SELECT usuario_id, modulo, permitido FROM public.permissoes_colaborador"
    )
    perm_map = {}
    for p in (perms or []):
        uid = str(p["usuario_id"])
        if uid not in perm_map: perm_map[uid] = {}
        perm_map[uid][p["modulo"]] = p["permitido"]

    result = []
    for u in (usuarios or []):
        uid = str(u["id"])
        padrao = perfil_modulos_padrao(u["perfil"])
        user_perms = {}
        for m in MODULOS_DISPONIVEIS:
            if uid in perm_map and m["id"] in perm_map[uid]:
                user_perms[m["id"]] = perm_map[uid][m["id"]]
            else:
                user_perms[m["id"]] = m["id"] in padrao
        result.append({
            "id": uid,
            "login": u["login"],
            "nome": u["nome"],
            "perfil": u["perfil"],
            "permissoes": user_perms,
        })
    return result

# FIM MÓDULO PERMISSÕES
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
# MURAL DE AVISOS
# ═══════════════════════════════════════════════════════════════════════════

# Tabela criada automaticamente no startup (ver evento startup)
MURAL_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS public.mural_avisos (
    id SERIAL PRIMARY KEY,
    titulo TEXT NOT NULL,
    mensagem TEXT NOT NULL,
    perfis TEXT DEFAULT '',
    destinatario TEXT DEFAULT '',
    ativo BOOLEAN DEFAULT true,
    criado_em TIMESTAMP DEFAULT NOW(),
    criado_por TEXT DEFAULT ''
)
"""

@app.on_event("startup")
async def criar_tabela_mural():
    try:
        jard_query(MURAL_TABLE_SQL, fetch="none")
        # Garantir coluna destinatario (tabela pode já existir sem ela)
        jard_query("ALTER TABLE public.mural_avisos ADD COLUMN IF NOT EXISTS destinatario TEXT DEFAULT ''", fetch="none")
    except Exception:
        pass

@app.get("/api/mural")
async def listar_mural(payload=Depends(verificar_token)):
    """Lista avisos ativos para o perfil/login do usuário."""
    perfil = payload.get("perfil", "")
    login = payload.get("login") or payload.get("sub", "")
    try:
        rows = jard_query(
            "SELECT id, titulo, mensagem, perfis, destinatario, criado_em, criado_por "
            "FROM public.mural_avisos WHERE ativo=true ORDER BY criado_em DESC",
            fetch="all"
        ) or []
    except Exception:
        # Coluna destinatario pode não existir ainda — migrar e tentar de novo
        try:
            jard_query("ALTER TABLE public.mural_avisos ADD COLUMN IF NOT EXISTS destinatario TEXT DEFAULT ''", fetch="none")
        except Exception:
            pass
        rows = jard_query(
            "SELECT id, titulo, mensagem, perfis, destinatario, criado_em, criado_por "
            "FROM public.mural_avisos WHERE ativo=true ORDER BY criado_em DESC",
            fetch="all"
        ) or []
    result = []
    for r in rows:
        dest = (r.get("destinatario") or "").strip()
        perfis_str = (r.get("perfis") or "").strip()
        perfis_list = [p.strip() for p in perfis_str.split(",") if p.strip()]
        # Destinatário individual → só ele vê
        if dest:
            if dest != login:
                continue
        # Filtro por perfil → só os listados
        elif perfis_list:
            if perfil not in perfis_list:
                continue
        # Sem filtro → todos veem
        result.append({
            "id": r["id"],
            "titulo": r["titulo"],
            "mensagem": r["mensagem"],
            "perfis": perfis_str,
            "destinatario": dest,
            "criado_em": r["criado_em"].isoformat() if r["criado_em"] else "",
            "criado_por": r.get("criado_por") or "",
        })
    return result

class MuralCreate(BaseModel):
    titulo: str
    mensagem: str
    perfis: str = ""  # "" = todos, ou "operador,campo,motorista"
    destinatario: str = ""  # "" = usa perfis, ou "gilson@garra.local" = só ele

@app.post("/api/mural")
async def criar_aviso_mural(dados: MuralCreate, payload=Depends(verificar_admin)):
    """Admin cria aviso no mural."""
    jard_query(
        "INSERT INTO public.mural_avisos (titulo, mensagem, perfis, destinatario, criado_por) VALUES (%s, %s, %s, %s, %s)",
        (dados.titulo, dados.mensagem, dados.perfis, dados.destinatario, payload.get("nome", "")), fetch="none"
    )
    return {"ok": True}

@app.put("/api/mural/{aviso_id}")
async def editar_aviso_mural(aviso_id: int, dados: MuralCreate, payload=Depends(verificar_admin)):
    """Admin edita um aviso existente."""
    jard_query(
        "UPDATE public.mural_avisos SET titulo=%s, mensagem=%s, perfis=%s, destinatario=%s WHERE id=%s",
        (dados.titulo, dados.mensagem, dados.perfis, dados.destinatario, aviso_id), fetch="none"
    )
    return {"ok": True}

@app.delete("/api/mural/{aviso_id}")
async def desativar_aviso_mural(aviso_id: int, payload=Depends(verificar_admin)):
    """Admin desativa aviso (soft delete)."""
    jard_query(
        "UPDATE public.mural_avisos SET ativo=false WHERE id=%s",
        (aviso_id,), fetch="none"
    )
    return {"ok": True}

# FIM MURAL
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
# MANUAL DO COLABORADOR (CARTILHA)
# ═══════════════════════════════════════════════════════════════════════════

CARTILHA_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS public.cartilha_blocos (
    id SERIAL PRIMARY KEY,
    ordem INTEGER NOT NULL DEFAULT 0,
    titulo TEXT NOT NULL,
    subtitulo TEXT DEFAULT '',
    conteudo TEXT NOT NULL DEFAULT '',
    ativo BOOLEAN DEFAULT true,
    atualizado_em TIMESTAMP DEFAULT NOW()
)
"""

CARTILHA_SEED = [
    (1, "Boas-vindas", "", "É com entusiasmo que nós da Garra Terraplenagem recebemos você em nossa casa. Você está ingressando em uma empresa sólida, que atua com excelência no setor da construção civil e é reconhecida pela qualidade de seus serviços, comprometimento com clientes e respeito às pessoas e ao meio ambiente.\n\nSe chegou até aqui é porque confiamos na sua capacidade em fazer a diferença. Conte conosco no seu desenvolvimento profissional."),
    (2, "Quem somos", "Nossa história", "A Garra Terraplenagem é uma empresa especializada em soluções para o setor da construção civil, com sede em Pará de Minas – MG e atuação em todo o território nacional. Fundada em 2016, construiu sua trajetória com base na excelência operacional, segurança e compromisso socioambiental.\n\nCom uma frota moderna, equipe qualificada e processos alinhados às melhores práticas do mercado, já executamos dezenas de projetos de grande porte.\n\nEm 2020, ampliamos nosso portfólio com a licença ambiental para operação de área de bota-fora, reforçando nosso papel na gestão responsável de resíduos da construção civil."),
    (3, "Missão, Visão e Valores", "", "**Missão**\nGerar valor para nossos clientes.\n\n**Visão**\nPreparamos terrenos para gerar valor ao nosso cliente e nos tornar referência no segmento.\n\n**Valores**\nRespeito, senso colaborativo, equipe, cuidado com o meio ambiente começando por nossa empresa."),
    (4, "Nossos Serviços", "", "- Terraplenagem\n- Demolição\n- Disk Entulho\n- Escavação\n- Destoca de Eucalipto\n- Furação para Tubulões\n- Limpeza de Lagoas\n- Biodigestores"),
    (5, "Deveres do Colaborador", "", "**1. Assiduidade e Pontualidade**\nComparecer pontualmente ao local de trabalho é obrigação fundamental, sendo critério relevante de desempenho e conduta profissional.\n\n**2. Registro de Ponto**\nÉ obrigatório registrar o ponto no início da jornada, no início e término do intervalo para refeição e ao final do expediente, respeitando a tolerância de até 5 minutos.\n\n**3. Envio de Atestado Médico**\nEm caso de ausência por motivo de saúde, o atestado deve ser enviado imediatamente via WhatsApp ao Departamento Pessoal e entregue fisicamente no retorno.\n\n**4. Uso e Higiene do Uniforme**\nO uso do uniforme fornecido pela empresa é obrigatório. O colaborador é responsável por mantê-lo em boas condições de higiene e conservação.\n\n**5. Cumprimento de Ordens**\nExecutar com zelo as tarefas designadas, observando as ordens da liderança, as normas internas e os padrões de qualidade exigidos.\n\n**6. Uso de Celular Pessoal**\nO colaborador poderá utilizar seu celular pessoal para fins profissionais durante a jornada, somente para uso profissional, visando agilidade e eficiência dos processos.\n\n**7. Segurança do Trabalho e Trânsito**\nCumprir todas as normas de segurança, incluindo o uso obrigatório de EPIs, bem como obedecer às leis de trânsito nas atividades externas.\n\n**8. Acidentes de Trânsito**\nComunicar imediatamente à empresa, podendo acionar o setor administrativo, liderança e as autoridades competentes (Bombeiro, PM e afins).\n\n**9. Multas de Trânsito**\nMultas por infrações do condutor serão de responsabilidade do colaborador, salvo falha mecânica previamente reportada por escrito no checklist.\n\n**10. Atualização de Dados**\nManter sempre atualizadas junto ao Departamento Pessoal as informações de endereço, telefone, estado civil e dependentes.\n\n**11. Limpeza e Organização**\nZelar pela higiene e conservação dos ambientes, especialmente banheiros, refeitórios e áreas operacionais.\n\n**12. Saídas fora de Férias**\nAusências por motivos particulares devem ser previamente autorizadas, sob pena de serem consideradas faltas injustificadas.\n\n**13. Comunicação de Faltas**\nFaltas devem ser comunicadas antecipadamente ao superior imediato, salvo emergências.\n\n**14. Exames Ocupacionais**\nSubmeter-se aos exames admissionais, periódicos, de retorno, de mudança de função ou demissionais.\n\n**15. Respeito Interpessoal**\nTratar colegas, superiores, clientes e terceiros com respeito, cordialidade e profissionalismo.\n\n**16. Devolução de Materiais**\nNo desligamento, devolver EPIs, uniformes, ferramentas e demais equipamentos. A não devolução poderá implicar desconto na rescisão."),
    (6, "Direitos do Colaborador", "", "**1. Pagamento de Salário**\nEfetuado até o 5º dia útil de cada mês. 13º em duas parcelas: 1ª até 30/nov, 2ª até 20/dez (com descontos de INSS e IRRF).\n\n**2. Adiantamento Salarial**\nAté 30% do salário, realizado no dia 20 de cada mês, mediante comunicação prévia ao DP.\n\n**3. Uniforme Fornecido**\nA empresa fornece os uniformes necessários ao exercício das funções.\n\n**4. Acesso a Dados Cadastrais**\nDireito de acesso e atualização dos dados mantidos pela empresa, conforme a LGPD.\n\n**5. Exames Gratuitos**\nTodos os exames ocupacionais exigidos por lei serão realizados sem custo para o colaborador.\n\n**6. Faltas Legais**\n2 dias por falecimento (avós, pais, filhos, esposa) · 3 dias por casamento · 5 dias por nascimento de filho(a) · 1 dia/ano para doação de sangue · Dias de prova vestibular · Dobro de dias de convocação eleitoral · 1 dia/ano para levar filho ao médico · 2 dias para pré-natal da esposa · Gestante: mínimo 6 consultas. Todos mediante documento comprobatório.\n\n**7. Licença Maternidade**\n120 dias, podendo a mãe escolher se tira tempo antes do parto, sem prejuízo do emprego e salário.\n\n**8. Licença Paternidade**\n5 dias consecutivos a partir do dia útil ao da data de nascimento, sem prejuízo de remuneração.\n\n**9. Férias**\nA cada 12 meses, podendo ser dividida em até 3 períodos (um ≥ 14 dias, demais ≥ 5 dias cada). Afastamento INSS > 6 meses = perda de férias proporcionais."),
    (7, "Práticas não permitidas", "", "**1. Informações Confidenciais**\nProibido divulgar dados de clientes, fornecedores, contratos, valores, processos ou qualquer conteúdo obtido em razão do vínculo.\n\n**2. Comportamento na Área de Alimentação**\nManter silêncio e respeito. Vedado consumo de bebida alcoólica e uso de cigarro nas áreas de alimentação.\n\n**3. Saída sem Autorização**\nVedado ausentar-se durante o expediente sem autorização prévia do superior imediato.\n\n**4. Uso de Equipamentos fora da Empresa**\nSó com autorização formal da liderança ou diretoria. Uso indevido = penalidades.\n\n**5. Serviços Particulares com Recursos da Empresa**\nProibido executar serviços pessoais utilizando máquinas, materiais ou tempo de trabalho da empresa. Pode ensejar justa causa.\n\n**6. Pessoas não Autorizadas**\nProibido trazer familiares, amigos ou crianças ao ambiente de trabalho ou obras sem autorização.\n\n**7. Lavagem de Veículos Particulares**\nNão permitida nas dependências da empresa, salvo com autorização escrita da direção.\n\n**8. Veículos da Empresa para Uso Pessoal**\nProibido caronas a não-funcionários, transportar menores ou usar para fins pessoais.\n\n**9. Uso Indevido de Conhecimentos**\nVedado utilizar conhecimento técnico, metodologia ou informação da empresa para fins pessoais ou repassar a terceiros.\n\n**10. Comercialização**\nNão é permitida a comercialização de quaisquer produtos ou serviços durante a jornada."),
    (8, "Punições", "", "Colaboradores que infringirem as normas estão sujeitos a: **advertência verbal**, **advertência escrita**, **suspensão** ou **dispensa por justa causa**. A ordem da penalidade pode ser aplicada de acordo com a gravidade do fato."),
    (9, "Conduta Ética", "", "- Banheiro: pense no próximo. Dê a descarga, cuide do assento, da pia e do chão.\n- Jogue o papel higiênico no lixo, não no vaso.\n- Ao sair, não deixe torneira aberta ou pingando, nem a luz acesa.\n- Limpe a mesa ao acabar a refeição. Higienize e guarde seus utensílios.\n- Não jogue restos de comida na pia. A cozinha é de uso coletivo.\n- Tenha sua garrafinha reutilizável. Um copo descartável leva até 450 anos para se decompor.\n- Respeite as diferenças e os espaços das outras pessoas.\n\nA empresa não se responsabiliza por objetos ou valores deixados nas dependências."),
    (10, "Canais de comunicação", "", "**Comunicação interna:** (37) 99153-1090\n**Comunicação externa:** (37) 3236-8625 | (37) 99971-8000\n**Site:** garraterraplenagem.com.br\n**Instagram:** @garraterraplenagem\n**Endereço:** Av. Santos Dumont, 346 – São Cristóvão, Pará de Minas - MG"),
]

@app.on_event("startup")
async def criar_tabela_cartilha():
    try:
        jard_query(CARTILHA_TABLE_SQL, fetch="none")
        existe = jard_query("SELECT COUNT(*) as c FROM public.cartilha_blocos", fetch="one")
        if existe and existe.get("c", 0) == 0:
            for ordem, titulo, subtitulo, conteudo in CARTILHA_SEED:
                jard_query(
                    "INSERT INTO public.cartilha_blocos (ordem, titulo, subtitulo, conteudo) VALUES (%s, %s, %s, %s)",
                    (ordem, titulo, subtitulo, conteudo), fetch="none"
                )
    except Exception:
        pass

@app.get("/api/cartilha")
async def listar_cartilha(payload=Depends(verificar_token)):
    """Lista blocos ativos do manual, em ordem — qualquer usuário logado pode ler."""
    rows = jard_query(
        "SELECT id, ordem, titulo, subtitulo, conteudo, atualizado_em "
        "FROM public.cartilha_blocos WHERE ativo=true ORDER BY ordem ASC, id ASC",
        fetch="all"
    ) or []
    return [
        {
            "id": r["id"], "ordem": r["ordem"], "titulo": r["titulo"],
            "subtitulo": r.get("subtitulo") or "", "conteudo": r["conteudo"],
        }
        for r in rows
    ]

class CartilhaBloco(BaseModel):
    ordem: int = 0
    titulo: str
    subtitulo: str = ""
    conteudo: str

@app.post("/api/cartilha")
async def criar_bloco_cartilha(dados: CartilhaBloco, payload=Depends(verificar_admin)):
    """Admin cria novo bloco no manual."""
    jard_query(
        "INSERT INTO public.cartilha_blocos (ordem, titulo, subtitulo, conteudo) VALUES (%s, %s, %s, %s)",
        (dados.ordem, dados.titulo, dados.subtitulo, dados.conteudo), fetch="none"
    )
    return {"ok": True}

@app.put("/api/cartilha/{bloco_id}")
async def editar_bloco_cartilha(bloco_id: int, dados: CartilhaBloco, payload=Depends(verificar_admin)):
    """Admin edita um bloco existente."""
    jard_query(
        "UPDATE public.cartilha_blocos SET ordem=%s, titulo=%s, subtitulo=%s, conteudo=%s, atualizado_em=NOW() WHERE id=%s",
        (dados.ordem, dados.titulo, dados.subtitulo, dados.conteudo, bloco_id), fetch="none"
    )
    return {"ok": True}

@app.delete("/api/cartilha/{bloco_id}")
async def excluir_bloco_cartilha(bloco_id: int, payload=Depends(verificar_admin)):
    """Admin remove um bloco definitivamente."""
    jard_query("DELETE FROM public.cartilha_blocos WHERE id=%s", (bloco_id,), fetch="none")
    return {"ok": True}

# FIM CARTILHA
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/checklist")
async def checklist_app():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "operacional", "checklist", "index.html")
    return FileResponse(path)

@app.get("/checklist/sw.js")
async def checklist_sw():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "operacional", "checklist", "sw.js")
    return FileResponse(path, media_type="application/javascript")

@app.get("/checklist/manifest.json")
async def checklist_manifest():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "operacional", "checklist", "manifest.json")
    return FileResponse(path)

@app.get("/mobile")
async def mobile_app():
    return FileResponse(os.path.join(os.path.dirname(__file__), "../../operacional/static/mobile.html"))

@app.get("/mobile/sw.js")
async def mobile_sw():
    return FileResponse(
        os.path.join(os.path.dirname(__file__), "../../operacional/static/sw.js"),
        media_type="application/javascript"
    )

@app.get("/mobile/manifest.json")
async def mobile_manifest():
    return FileResponse(os.path.join(os.path.dirname(__file__), "../../operacional/static/mobile.manifest.json"))

# ── FALLBACK — compatibilidade com browsers que cachearam URLs antigas ───────
from fastapi.responses import RedirectResponse

@app.get("/manifest.json")
async def redirect_manifest():
    return RedirectResponse(url="/mobile/manifest.json")

@app.get("/sw.js")
async def redirect_sw():
    return RedirectResponse(url="/mobile/sw.js")

@app.get("/favicon.ico")
async def redirect_favicon():
    return RedirectResponse(url="/static/icons/favicon.ico")

@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    from fastapi.responses import JSONResponse, Response
    path = request.url.path
    if path.startswith("/jardinagem/api/") or path.startswith("/api/") or path.startswith("/auth/") or path.startswith("/usuarios") or path.startswith("/checklist/") or path.startswith("/frota") or path.startswith("/logistica/") or path.startswith("/operacional/"):
        return JSONResponse({"ok": False, "error": "Rota não encontrada", "path": path}, status_code=404)
    return Response(status_code=404)

@app.exception_handler(500)
async def server_error_handler(request: Request, exc):
    from fastapi.responses import JSONResponse, Response
    path = request.url.path
    if path.startswith("/jardinagem/api/") or path.startswith("/api/") or path.startswith("/auth/") or path.startswith("/usuarios") or path.startswith("/checklist/") or path.startswith("/frota") or path.startswith("/logistica/") or path.startswith("/operacional/"):
        return JSONResponse({"ok": False, "error": "Erro interno do servidor"}, status_code=500)
    return Response(status_code=500)
    raise exc

# ── HEALTH CHECK — mantém banco Neon acordado ──────────────────
@app.get("/api/health")
async def health():
    """
    Health check LEVE — não toca no banco.
    Serve apenas para o Render saber que o processo está vivo.
    NÃO usar este endpoint em cron de keep-alive contra o banco:
    manter o Neon acordado 24/7 estoura a cota de compute do free tier.
    Para testar o banco use /api/health/db (manual).
    """
    return {"status": "ok", "sistema": "Garra Gestão API", "app": "vivo"}

@app.get("/api/health/db")
async def health_db():
    """Testa a conexão com o banco — uso manual de diagnóstico, NÃO em cron."""
    try:
        jard_query("SELECT 1", fetch="one")
        return {"status": "ok", "db": "conectado"}
    except Exception as e:
        return {"status": "erro", "db": str(e)}

@app.get("/api/debug/jardinagem-pares")
async def debug_jard_pares(mes: str = "", chave: str = ""):
    """Diagnóstico de pares: duplicados, vazios e sequência.
    Uso: ?chave=DEBUG_KEY (opcional &mes=ID_DO_MES)"""
    if not _debug_autorizado(chave):
        raise HTTPException(status_code=403, detail="Chave inválida")
    filtro = "AND s.mes_id = %s" if mes else ""
    params = (mes,) if mes else ()
    pares = jard_query(
        f"""SELECT p.id, p.codigo_a, p.codigo_d, p.local_nome, p.semana_id,
                   s.label AS semana_label, s.mes_id,
                   (SELECT COUNT(*) FROM jardinagem.fotos f
                    WHERE f.par_id = p.id) AS num_fotos
            FROM jardinagem.pares p
            LEFT JOIN jardinagem.semanas s ON s.id = p.semana_id
            WHERE (p.ativo IS NULL OR p.ativo=true) {filtro}
            ORDER BY p.codigo_a, p.id""",
        params
    )
    pares = [dict(p) for p in (pares or [])]
    # Detectar duplicados de codigo_a
    vistos = {}
    duplicados = []
    vazios = []
    for p in pares:
        ca = p.get("codigo_a")
        if ca in vistos:
            duplicados.append({"codigo_a": ca, "ids": [vistos[ca], p["id"]]})
        else:
            vistos[ca] = p["id"]
        if not p.get("num_fotos"):
            vazios.append({"id": p["id"], "codigo_a": ca, "local": p.get("local_nome")})
    cfg = jard_query("SELECT valor FROM jardinagem.config WHERE chave='next_code'", fetch="one")
    return {
        "total_pares": len(pares),
        "next_code_config": cfg["valor"] if cfg else None,
        "duplicados": duplicados,
        "vazios_sem_foto": vazios,
        "pares": pares
    }

@app.get("/api/debug/os")
async def debug_os(numero: str = "", chave: str = ""):
    """Diagnóstico de uma OS e suas partes. Uso: ?numero=OS-2026-0005&chave=DEBUG_KEY"""
    if not _debug_autorizado(chave):
        raise HTTPException(status_code=403, detail="Chave inválida")
    os_row = jard_query(
        """SELECT id, numero, obra, regime_cobranca, valor_combinado, status,
                  equipamento_id, operador_id, tipo_servico_id, data_inicio
           FROM operacional.ordens_servico WHERE numero=%s""",
        (numero,), fetch="one"
    )
    if not os_row:
        return {"erro": "OS não encontrada", "numero": numero}
    partes = jard_query(
        """SELECT id, data, tipo_medicao,
                  horimetro_inicial, horimetro_final, horas_trabalhadas, horas_cobradas,
                  km_inicial, km_final, km_percorrido, qtd_viagens, qtd_metros,
                  hora_inicio, hora_fim, observacao, criado_em
           FROM operacional.partes_diarias
           WHERE os_id=%s AND ativo=true
           ORDER BY data, criado_em""",
        (os_row["id"],)
    )
    return {
        "os": dict(os_row),
        "total_partes": len(partes or []),
        "partes": [dict(p) for p in (partes or [])]
    }

@app.get("/api/debug/equipamentos")
async def debug_equipamentos(codigo: str = "", chave: str = ""):
    """Diagnóstico de equipamentos e responsável. Uso: ?chave=DEBUG_KEY (ou &codigo=CB-037)"""
    if not _debug_autorizado(chave):
        raise HTTPException(status_code=403, detail="Chave inválida")
    filtro = "WHERE eq.codigo=%s" if codigo else ""
    params = (codigo,) if codigo else ()
    rows = jard_query(
        f"""SELECT eq.codigo, eq.descricao, eq.categoria, eq.medicao,
                   eq.operador_responsavel_id, resp.nome AS responsavel_nome,
                   eq.ativo
            FROM operacional.equipamentos eq
            LEFT JOIN public.usuarios_garra resp ON resp.id = eq.operador_responsavel_id
            {filtro}
            ORDER BY eq.codigo""",
        params
    )
    return {"total": len(rows or []), "equipamentos": [dict(r) for r in (rows or [])]}

@app.get("/api/debug/usuarios")
async def debug_usuarios(chave: str = "", authorization: Optional[str] = Header(None)):
    """Diagnóstico de usuários. Acesso: admin logado OU chave de diagnóstico."""
    # Permite acesso com chave de diagnóstico (para resolver problema de login)
    autorizado = _debug_autorizado(chave)
    if not autorizado:
        # Senão exige admin via token
        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Não autenticado")
        try:
            payload = pyjwt.decode(authorization[7:], JWT_SECRET, algorithms=["HS256"])
            if payload.get("perfil") != "admin":
                raise HTTPException(status_code=403, detail="Acesso restrito a administradores")
        except pyjwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Token inválido")
    rows = jard_query(
        """SELECT login, nome, email, perfil, perfil_checklist, ativo,
                  LEFT(senha_hash,7) AS hash_inicio,
                  CASE WHEN senha_hash = '$2b$12$y4jgMhNSKtoeBtad7lKEOev.tHk8S9OA1SpPHrowz5XT.AQJK.iZK'
                       THEN 'padrao_1234' ELSE 'outra' END AS senha_status
           FROM public.usuarios_garra
           ORDER BY ativo DESC, perfil, login""",
        fetch="all"
    )
    return [dict(r) for r in (rows or [])]

@app.get("/api/debug/sistema")
async def debug_sistema(chave: str = ""):
    """Diagnóstico completo do sistema — passo a passo de todas as áreas.
    Uso: /api/debug/sistema?chave=DEBUG_KEY"""
    if not _debug_autorizado(chave):
        raise HTTPException(status_code=403, detail="Chave inválida")

    import datetime as _dt
    rel = {"timestamp": _dt.datetime.now().isoformat(), "checks": []}

    def add(area, item, ok, detalhe=""):
        rel["checks"].append({
            "area": area, "item": item,
            "status": "OK" if ok else "FALHA", "detalhe": str(detalhe)
        })

    # 1. BANCO — conexão
    try:
        r = jard_query("SELECT 1 AS ok", fetch="one")
        add("banco", "conexão Neon", bool(r), "conectado")
    except Exception as e:
        add("banco", "conexão Neon", False, e)

    # 2. TABELAS essenciais existem
    tabelas = [
        ("public", "usuarios_garra"),
        ("operacional", "ordens_servico"),
        ("operacional", "equipamentos"),
        ("operacional", "partes_diarias"),
        ("jardinagem", "meses"),
        ("jardinagem", "semanas"),
        ("jardinagem", "pares"),
        ("jardinagem", "fotos"),
    ]
    for sch, tab in tabelas:
        try:
            n = jard_query(
                f"SELECT COUNT(*) AS n FROM {sch}.{tab}", fetch="one"
            )
            add("tabelas", f"{sch}.{tab}", True, f"{n['n']} registros")
        except Exception as e:
            add("tabelas", f"{sch}.{tab}", False, e)

    # 3. USUÁRIOS — quantos ativos e perfis
    try:
        us = jard_query(
            "SELECT perfil, COUNT(*) AS n FROM public.usuarios_garra "
            "WHERE ativo=true GROUP BY perfil ORDER BY perfil",
            fetch="all"
        )
        perfis = {u["perfil"]: u["n"] for u in (us or [])}
        add("usuarios", "ativos por perfil", bool(perfis), perfis)
    except Exception as e:
        add("usuarios", "ativos por perfil", False, e)

    # 4. JARDINAGEM — integridade dos pares (duplicados/vazios)
    try:
        pares = jard_query(
            "SELECT codigo_a, codigo_d FROM jardinagem.pares "
            "WHERE (ativo IS NULL OR ativo=true) ORDER BY codigo_a",
            fetch="all"
        )
        pares = [dict(p) for p in (pares or [])]
        codigos = [p["codigo_a"] for p in pares if p["codigo_a"]]
        dups = [c for c in set(codigos) if codigos.count(c) > 1]
        vazios = [p for p in pares if not p.get("codigo_a")]
        # buracos na sequência
        nums = sorted(set(int(c) for c in codigos if str(c).isdigit()))
        buracos = []
        if nums:
            for x in range(nums[0], nums[-1] + 1):
                if x not in nums:
                    buracos.append(x)
        ok = (len(dups) == 0 and len(vazios) == 0 and len(buracos) == 0)
        add("jardinagem", "integridade pares", ok, {
            "total": len(pares),
            "duplicados": dups,
            "vazios": len(vazios),
            "buracos": buracos[:10],
            "faixa": f"{nums[0]}–{nums[-1]}" if nums else "—",
        })
    except Exception as e:
        add("jardinagem", "integridade pares", False, e)

    # 5. JARDINAGEM — next_code coerente
    try:
        cfg = jard_query(
            "SELECT valor FROM jardinagem.config WHERE chave='next_code'",
            fetch="one"
        )
        maxc = jard_query(
            "SELECT MAX(codigo_d) AS m FROM jardinagem.pares WHERE ativo",
            fetch="one"
        )
        nc = int(cfg["valor"]) if cfg else None
        mc = maxc["m"] if maxc else None
        ok = (nc is not None and mc is not None and nc > mc)
        add("jardinagem", "next_code", ok,
            f"next_code={nc}, max_codigo_d={mc}")
    except Exception as e:
        add("jardinagem", "next_code", False, e)

    # 6. JARDINAGEM — trava UNIQUE anti-duplicação ativa
    try:
        idx = jard_query(
            "SELECT indexname FROM pg_indexes "
            "WHERE schemaname='jardinagem' AND tablename='pares' "
            "AND indexname='uq_pares_codigo_a_ativo'",
            fetch="one"
        )
        add("jardinagem", "trava UNIQUE", bool(idx),
            "ativa" if idx else "AUSENTE — risco de duplicação")
    except Exception as e:
        add("jardinagem", "trava UNIQUE", False, e)

    # 7. OPERACIONAL — colunas novas existem
    try:
        cols = jard_query(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema='operacional' AND table_name='partes_diarias' "
            "AND column_name IN ('sem_almoco','fornecedor','equipamento_terceiro')",
            fetch="all"
        )
        nomes = {c["column_name"] for c in (cols or [])}
        faltam = {"sem_almoco", "fornecedor", "equipamento_terceiro"} - nomes
        add("operacional", "colunas partes_diarias", not faltam,
            "todas presentes" if not faltam else f"faltam: {faltam}")
    except Exception as e:
        add("operacional", "colunas partes_diarias", False, e)

    # 8. OPERACIONAL — operador_responsavel em equipamentos
    try:
        col = jard_query(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema='operacional' AND table_name='equipamentos' "
            "AND column_name='operador_responsavel_id'",
            fetch="one"
        )
        add("operacional", "operador_responsavel_id", bool(col),
            "presente" if col else "AUSENTE")
    except Exception as e:
        add("operacional", "operador_responsavel_id", False, e)

    # Resumo
    falhas = [c for c in rel["checks"] if c["status"] == "FALHA"]
    rel["resumo"] = {
        "total_checks": len(rel["checks"]),
        "ok": len(rel["checks"]) - len(falhas),
        "falhas": len(falhas),
        "areas_com_falha": sorted(set(c["area"] for c in falhas)),
    }
    return rel

@app.get("/")
async def root():
    return RedirectResponse(url="/admin")

@app.get("/jardinagem/api/health")
async def jard_health():
    try:
        jard_query("SELECT 1", fetch="one")
        return {"status":"ok","db":"conectado","modulo":"jardinagem"}
    except Exception as e:
        return {"status":"erro","db":str(e)}
